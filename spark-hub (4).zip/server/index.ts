import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import fs from "fs";
import path from "path";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Dynamic sitemap.xml for SEO
  app.get("/sitemap.xml", (_req, res) => {
    try {
      const host = (_req.protocol || "https") + "://" + (_req.get("host") || "localhost");
      const urls: { loc: string; lastmod?: string; changefreq?: string; priority?: string }[] = [];

      const add = (p: string, lastmod?: string, priority = "0.8", changefreq = "weekly") => {
        urls.push({ loc: `${host}${p}`, lastmod, priority, changefreq });
      };

      // Static routes
      ["/", "/about", "/services", "/services/misa-licensing", "/contact", "/blog"].forEach((p) => add(p, new Date().toISOString(), p === "/" ? "1.0" : "0.8", "weekly"));

      // Blog articles from markdown files
      const articlesDir = path.join(process.cwd(), "client", "articles");
      if (fs.existsSync(articlesDir)) {
        const files = fs.readdirSync(articlesDir).filter((f) => f.endsWith(".md"));
        for (const file of files) {
          const slug = file.replace(/\.md$/, "");
          let lastmod: string | undefined;
          try {
            const full = path.join(articlesDir, file);
            const content = fs.readFileSync(full, "utf8");
            const publishedLine = content.split(/\r?\n/).find((l) => /Published:/i.test(l));
            if (publishedLine) {
              const m = publishedLine.match(/Published:\s*([^|_]+)/i);
              if (m && m[1]) {
                const d = new Date(m[1].trim());
                if (!isNaN(d.getTime())) lastmod = d.toISOString();
              }
            }
            if (!lastmod) {
              const stat = fs.statSync(full);
              lastmod = stat.mtime.toISOString();
            }
          } catch {
            // ignore parse errors
          }
          add(`/blog/${slug}`, lastmod, "0.6", "monthly");
        }
      }

      const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
        .map((u) => {
          return [
            "  <url>",
            `    <loc>${u.loc}</loc>`,
            u.lastmod ? `    <lastmod>${u.lastmod}</lastmod>` : "",
            u.changefreq ? `    <changefreq>${u.changefreq}</changefreq>` : "",
            u.priority ? `    <priority>${u.priority}</priority>` : "",
            "  </url>",
          ]
            .filter(Boolean)
            .join("\n");
        })
        .join("\n")}\n</urlset>`;

      res.setHeader("Content-Type", "application/xml");
      res.status(200).send(xml);
    } catch (e) {
      res.status(500).send("<error>could not generate sitemap</error>");
    }
  });

  return app;
}
