import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { CalendarDays, Clock3, Share2 } from "lucide-react";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PostCard } from "@/components/blog/PostCard";
import {
  BlogPostCoreMeta,
  BlogPostMeta,
  extractArticleMeta,
  extractPostMeta,
  parsePostDate,
} from "@/lib/blog";

const files = import.meta.glob("../articles/*.md", { query: "?raw", import: "default" });

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export default function BlogArticle() {
  const { slug } = useParams();
  const [content, setContent] = useState<string | null>(null);
  const [meta, setMeta] = useState<BlogPostCoreMeta | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<BlogPostMeta[]>([]);
  const [loading, setLoading] = useState(true);

  const fileKey = useMemo(() => (slug ? `../articles/${slug}.md` : ""), [slug]);
  const canonical = typeof window !== "undefined" ? window.location.href : "";
  const origin = typeof window !== "undefined" ? window.location.origin : "";

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!slug) {
        setContent(null);
        setMeta(null);
        setRelatedPosts([]);
        setLoading(false);
        return;
      }
      const loader = (files as Record<string, () => Promise<string>>)[fileKey];
      if (!loader) {
        if (!cancelled) {
          setContent(null);
          setMeta(null);
          setRelatedPosts([]);
          setLoading(false);
        }
        return;
      }
      setLoading(true);
      const markdown = await loader();
      if (cancelled) return;
      const articleMeta = extractArticleMeta(markdown);
      setContent(markdown);
      setMeta(articleMeta);
      setLoading(false);
      if (typeof document !== "undefined") {
        document.title = `${articleMeta.title} | SafaArban Blog`;
      }

      const relatedEntries = await Promise.all(
        Object.entries(files)
          .filter(([path]) => path !== fileKey)
          .map(async ([path, entryLoader]) => {
            const raw = await (entryLoader as () => Promise<string>)();
            const entrySlug = path.split("/").pop()!.replace(/\.md$/, "");
            return extractPostMeta(entrySlug, raw);
          }),
      );
      if (cancelled) return;
      relatedEntries.sort((a, b) => parsePostDate(b.date) - parsePostDate(a.date));
      const categoryMatches = articleMeta.category
        ? relatedEntries.filter((entry) => entry.category === articleMeta.category)
        : [];
      setRelatedPosts((categoryMatches.length ? categoryMatches : relatedEntries).slice(0, 3));
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [fileKey, slug]);

  const toc = useMemo(() => {
    if (!content) return [] as { level: number; text: string; id: string }[];
    const items: { level: number; text: string; id: string }[] = [];
    const regex = /^(#{2,3})\s+(.+)$/gm;
    let match: RegExpExecArray | null;
    while ((match = regex.exec(content)) !== null) {
      const level = match[1].length;
      const text = match[2].trim();
      const id = slugify(text);
      items.push({ level, text, id });
    }
    return items;
  }, [content]);

  const ogImage = useMemo(() => {
    if (!content) return undefined;
    const found = content.match(/!\[[^\]]*\]\(([^(\s]+)(?:\s+\"[^\"]*\")?\)/);
    return found ? found[1] : undefined;
  }, [content]);

  const articleJsonLd = meta
    ? [
        {
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: origin ? `${origin}/` : undefined },
            { "@type": "ListItem", position: 2, name: "Blog", item: origin ? `${origin}/blog` : undefined },
            { "@type": "ListItem", position: 3, name: meta.title, item: canonical || undefined },
          ],
        },
        {
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          headline: meta.title,
          description: meta.excerpt,
          datePublished: meta.date,
          dateModified: meta.date,
          mainEntityOfPage: canonical || undefined,
          author: { "@type": "Organization", name: "SafaArban" },
          publisher: {
            "@type": "Organization",
            name: "SafaArban",
            logo: { "@type": "ImageObject", url: origin ? `${origin}/placeholder.svg` : undefined },
          },
          image: ogImage ? [ogImage] : undefined,
        },
      ]
    : undefined;

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";

  function shareInsight() {
    if (typeof navigator !== "undefined" && navigator.share) {
      navigator.share({ title: meta?.title || "SafaArban Insight", url: shareUrl }).catch(() => undefined);
      return;
    }
    if (typeof window !== "undefined") {
      const linkedInUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(meta?.title || "SafaArban Insight")}`;
      window.open(linkedInUrl, "_blank", "noopener,noreferrer");
    }
  }

  const NotFound = (
    <section className="py-24">
      <div className="mx-auto max-w-xl px-4 text-center">
        <h1 className="text-3xl font-bold text-navy">Article not found</h1>
        <p className="mt-3 text-sm text-muted">The insight you are looking for might have moved or been archived.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Button asChild variant="outline" className="border-gray-300 text-navy hover:bg-gray-50">
            <Link to="/blog">← Back to Blog</Link>
          </Button>
          <Button asChild className="bg-navy text-white hover:bg-navy-600">
            <Link to="/contact">Talk to an advisor</Link>
          </Button>
        </div>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen bg-white">
      {meta && (
        <SEO
          title={`${meta.title} | SafaArban Blog`}
          description={meta.excerpt || meta.title}
          type="article"
          canonical={canonical}
          ogImage={ogImage}
          keywords={[
            "saudi arabia",
            "business setup",
            "misa",
            "zatca",
            "company formation",
            meta.category || "saudi business",
          ]}
          jsonLd={articleJsonLd}
        />
      )}
      <Header />

      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-gray-50 via-white to-gray-100 py-16">
          <div className="absolute -top-24 left-0 h-64 w-64 rounded-full bg-coral-100/60 blur-3xl" />
          <div className="absolute -bottom-32 right-8 h-72 w-72 rounded-full bg-navy/10 blur-3xl" />
          <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6">
            {meta?.category && (
              <Badge className="mx-auto w-fit bg-coral/10 text-coral">{meta.category}</Badge>
            )}
            <h1 className="mt-6 text-3xl font-bold text-navy sm:text-4xl lg:text-5xl">
              {meta?.title || slug}
            </h1>
            {meta?.excerpt && <p className="mt-4 text-lg text-muted">{meta.excerpt}</p>}
            {(meta?.date || meta?.readTime) && (
              <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm text-muted">
                {meta?.date && (
                  <span className="inline-flex items-center gap-2">
                    <CalendarDays className="h-4 w-4 text-coral" />
                    {meta.date}
                  </span>
                )}
                {meta?.readTime && (
                  <span className="inline-flex items-center gap-2">
                    <Clock3 className="h-4 w-4 text-coral" />
                    {meta.readTime}
                  </span>
                )}
              </div>
            )}
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Button onClick={shareInsight} variant="secondary" className="bg-white text-navy hover:bg-white/80">
                <Share2 className="h-4 w-4" />
                Share insight
              </Button>
              <Button asChild variant="outline" className="border-gray-300 text-navy hover:bg-gray-50">
                <Link to="/contact">Request implementation support</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            {loading ? (
              <div className="grid gap-8 lg:grid-cols-[3fr_1fr]">
                <Card className="h-[480px] animate-pulse border-gray-200 bg-white/70" />
                <Card className="h-80 animate-pulse border-gray-200 bg-white/70" />
              </div>
            ) : !content ? (
              NotFound
            ) : (
              <div className="grid gap-10 lg:grid-cols-[3fr_1fr]">
                <article className="lg:col-span-3">
                  <div className="prose prose-lg mx-auto max-w-none prose-headings:text-navy prose-a:text-coral prose-strong:text-navy">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={{
                        h2: ({ children, ...props }) => {
                          const text = String(children ?? "");
                          const id = slugify(text);
                          return (
                            <h2 id={id} {...props}>
                              {children}
                            </h2>
                          );
                        },
                        h3: ({ children, ...props }) => {
                          const text = String(children ?? "");
                          const id = slugify(text);
                          return (
                            <h3 id={id} {...props}>
                              {children}
                            </h3>
                          );
                        },
                        img: ({ ...props }) => (
                          // eslint-disable-next-line jsx-a11y/alt-text
                          <img className="rounded-xl shadow-md" loading="lazy" {...props} />
                        ),
                        a: ({ ...props }) => (
                          <a
                            {...props}
                            target={props.href?.startsWith("http") ? "_blank" : undefined}
                            rel={props.href?.startsWith("http") ? "noopener noreferrer" : undefined}
                          />
                        ),
                      }}
                    >
                      {content}
                    </ReactMarkdown>
                  </div>

                  <div className="mt-14 rounded-2xl border border-gray-200 bg-white p-8 shadow-sm">
                    <h3 className="text-lg font-semibold text-navy">Need tailored execution support?</h3>
                    <p className="mt-3 text-sm text-muted">
                      Our team can align the licensing roadmap to your corporate structure, timeline, and sector requirements.
                    </p>
                    <div className="mt-6 flex flex-wrap gap-3">
                      <Button asChild className="bg-navy text-white hover:bg-navy-600">
                        <Link to="/contact">Schedule a strategy session</Link>
                      </Button>
                      <Button asChild variant="outline" className="border-gray-300 text-navy hover:bg-gray-50">
                        <Link to="/blog">← Back to insights</Link>
                      </Button>
                    </div>
                  </div>
                </article>

                <aside className="lg:col-span-1">
                  <div className="sticky top-24 space-y-6">
                    <Card className="border-gray-200 shadow-sm">
                      <CardHeader>
                        <CardTitle className="text-base font-semibold text-navy">Speak with a specialist</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3 text-sm text-muted">
                        <p>Get bespoke guidance for market entry, licensing, and compliance planning.</p>
                        <div className="space-y-2">
                          <Button asChild size="sm" className="w-full bg-navy text-white hover:bg-navy-600">
                            <Link to="/contact">Request consultation</Link>
                          </Button>
                          <Button asChild variant="outline" size="sm" className="w-full border-gray-300 text-navy hover:bg-gray-50">
                            <a href="https://wa.me/966536182180" target="_blank" rel="noopener noreferrer">
                              WhatsApp our team
                            </a>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {toc.length > 0 && (
                      <Card className="border-gray-200 shadow-sm">
                        <CardHeader>
                          <CardTitle className="text-base font-semibold text-navy">In this article</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <nav className="space-y-2 text-sm">
                            {toc.map((item) => (
                              <a
                                key={item.id}
                                href={`#${item.id}`}
                                className="block rounded-md px-3 py-2 text-navy/80 transition hover:bg-gray-50 hover:text-coral"
                                style={{ paddingLeft: item.level === 3 ? 24 : 12 }}
                              >
                                {item.text}
                              </a>
                            ))}
                          </nav>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </aside>
              </div>
            )}
          </div>
        </section>

        {relatedPosts.length > 0 && (
          <section className="bg-gray-50 py-16 lg:py-24">
            <div className="mx-auto max-w-6xl px-4 sm:px-6">
              <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-navy">Related insights</h2>
                  <p className="text-sm text-muted">Continue exploring regulatory updates and practical guidance.</p>
                </div>
                <Button asChild variant="ghost" className="text-sm text-coral hover:text-coral">
                  <Link to="/blog">View all articles</Link>
                </Button>
              </div>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {relatedPosts.map((post) => (
                  <PostCard key={post.slug} post={post} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  );
}
