import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function Index() {
  const pageTitle = "SafaArban - Saudi Arabia Business Setup & MISA Licensing Services";
  const pageDescription =
    "Expert Saudi business setup services for 100% foreign-owned companies. MISA licensing, Commercial Registration, ZATCA compliance, and complete business formation solutions.";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "SafaArban",
      url: origin || undefined,
      logo: origin ? `${origin}/placeholder.svg` : undefined,
      sameAs: ["https://wa.me/966536182180", "mailto:hello@safaarban.com"],
      contactPoint: [
        {
          "@type": "ContactPoint",
          contactType: "customer support",
          telephone: "+966536182180",
          areaServed: "SA",
        },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: "SafaArban",
      url: origin || undefined,
      potentialAction: {
        "@type": "SearchAction",
        target: origin ? `${origin}/blog?query={search_term_string}` : undefined,
        "query-input": "required name=search_term_string",
      },
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={pageTitle}
        description={pageDescription}
        keywords={[
          "saudi business setup",
          "misa license",
          "company formation saudi arabia",
          "commercial registration",
          "zatca compliance",
          "gosi registration",
          "saudi premium residency",
        ]}
        type="website"
        jsonLd={jsonLd}
      />
      <Header />

      <main>
        {/* Hero Section - Enhanced */}
        <section className="relative overflow-hidden bg-gradient-to-b from-gray-50/60 to-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16 lg:py-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block mb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-navy bg-blue-50 px-3 py-1 rounded-full">
                    Saudi Arabia's Premier Business Setup Specialists
                  </span>
                </div>
                <h1 className="text-4xl lg:text-5xl font-bold text-navy leading-tight mb-6">
                  Launch & grow a{" "}
                  <span className="text-coral">100% foreign‑owned</span>{" "}
                  business in Saudi Arabia — end‑to‑end.
                </h1>
                <p className="text-lg text-muted mb-8 max-w-lg">
                  Expert Saudi business setup services including MISA investment
                  licensing, Commercial Registration (CR), ZATCA e-invoicing
                  compliance, GOSI registration, municipality permits, and
                  complete business formation solutions for international
                  companies.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <Button
                    size="lg"
                    asChild
                    className="bg-navy text-white hover:bg-navy-600 shadow-lg"
                  >
                    <Link to="/contact">Get a Custom Quote</Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    asChild
                    className="border-gray-300 text-navy hover:bg-gray-50"
                  >
                    <Link to="/services">Explore Services</Link>
                  </Button>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-2 bg-coral-50 border border-dashed border-coral-200 rounded-full text-coral font-semibold text-sm">
                  <span className="w-2 h-2 bg-coral rounded-full"></span>
                  No prices displayed — tailored proposals only
                </div>
              </div>

              <div className="space-y-6">
                {/* Hero Image */}
                <div className="relative rounded-2xl overflow-hidden shadow-xl">
                  <img
                    src="https://images.pexels.com/photos/7984742/pexels-photo-7984742.jpeg"
                    alt="Professional Saudi business consultation"
                    className="w-full h-64 lg:h-80 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy/80 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <h3 className="text-xl font-bold mb-2">
                        Expert Saudi Business Setup
                      </h3>
                      <p className="text-sm opacity-90">
                        Professional guidance for foreign investors
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <Card className="border-gray-200 shadow-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">MISA License</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted">
                        Investment license preparation, filing & approvals.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-gray-200 shadow-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">CR Registration</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted">
                        Company formation, articles, Chamber, notary
                        coordination.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-gray-200 shadow-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">Compliance</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted">
                        ZATCA, GOSI, Qiwa, municipality, Saudization,
                        e‑invoicing.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Vision 2030 Opportunity Section */}
        <section className="py-16 bg-gradient-to-r from-navy to-navy-600 text-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                  Vision 2030: Unprecedented Opportunities
                </h2>
                <p className="text-lg mb-6 opacity-90">
                  Saudi Arabia's Vision 2030 has opened doors to massive foreign
                  investment opportunities. With over $3.2 trillion in planned
                  investments, new economic cities, NEOM mega-project, and
                  complete economic diversification, now is the perfect time to
                  establish your business in the Kingdom.
                </p>
                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div>
                    <div className="text-3xl font-bold text-accent mb-2">
                      $3.2T
                    </div>
                    <div className="text-sm opacity-90">
                      Investment Pipeline
                    </div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-accent mb-2">
                      100%
                    </div>
                    <div className="text-sm opacity-90">Foreign Ownership</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-accent mb-2">
                      25+
                    </div>
                    <div className="text-sm opacity-90">Mega Projects</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-accent mb-2">
                      150+
                    </div>
                    <div className="text-sm opacity-90">Eligible Sectors</div>
                  </div>
                </div>
                <Button
                  variant="secondary"
                  asChild
                  className="bg-white text-navy hover:bg-gray-50"
                >
                  <Link to="/contact">Explore Opportunities</Link>
                </Button>
              </div>
              <div className="relative rounded-xl overflow-hidden shadow-lg">
                <img
                  src="https://images.pexels.com/photos/15483696/pexels-photo-15483696.jpeg"
                  alt="Saudi Arabia flag representing Vision 2030 opportunities"
                  className="w-full h-80 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-lg font-bold">
                      Kingdom of Opportunities
                    </h3>
                    <p className="text-sm opacity-90">
                      Your gateway to the Middle East
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Complete Service Portfolio */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            {/* Services Header with Image */}
            <div className="grid lg:grid-cols-2 gap-8 items-center mb-12">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-4">
                  Complete Service Portfolio
                </h2>
                <p className="text-lg text-muted mb-6">
                  Comprehensive Saudi business setup and compliance services
                  tailored for international investors and companies seeking
                  100% foreign ownership. From MISA licensing to ongoing PRO
                  services, we handle every aspect of your business
                  establishment and compliance journey.
                </p>
                <Button
                  variant="outline"
                  asChild
                  className="border-gray-300 text-navy hover:bg-gray-50"
                >
                  <Link to="/contact">Request a Proposal</Link>
                </Button>
              </div>
              <div className="relative rounded-xl overflow-hidden shadow-lg">
                <img
                  src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg"
                  alt="Professional business partnership and consultation"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-navy/70 to-transparent flex items-center">
                  <div className="p-6 text-white">
                    <h3 className="text-lg font-bold">Trusted Partnership</h3>
                    <p className="text-sm opacity-90">
                      Your success is our commitment
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  tag: "MISA",
                  title: "Investment License",
                  description:
                    "Complete MISA investment license processing for 100% foreign-owned entities. Eligibility assessment, documentation preparation, translation services, application filing, and approval management.",
                  benefits: [
                    "20-30 day processing",
                    "Expert guidance",
                    "Document preparation",
                    "Government liaison",
                  ],
                  image:
                    "https://images.pexels.com/photos/7641842/pexels-photo-7641842.jpeg",
                },
                {
                  tag: "MoC",
                  title: "Company Formation (CR)",
                  description:
                    "End-to-end Commercial Registration including Articles of Association drafting, notarization, CR issuance, Chamber attestation, and official sealing.",
                  benefits: [
                    "Legal entity creation",
                    "Chamber membership",
                    "Banking facilitation",
                    "Tax registration prep",
                  ],
                  image:
                    "https://images.pexels.com/photos/7641842/pexels-photo-7641842.jpeg",
                },
                {
                  tag: "Compliance",
                  title: "ZATCA, GOSI, & Qiwa",
                  description:
                    "Complete tax/VAT registration, social insurance setup, e-invoicing implementation, payroll registration, and Saudization strategy development.",
                  benefits: [
                    "Tax compliance",
                    "Employee coverage",
                    "E-invoicing setup",
                    "Nitaqat planning",
                  ],
                  image:
                    "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg",
                },
                {
                  tag: "Municipality",
                  title: "Municipal Licensing",
                  description:
                    "Location-specific municipal permits, activity mapping, site inspection coordination, signage approvals, and health & safety clearances.",
                  benefits: [
                    "Local permits",
                    "Activity approvals",
                    "Site inspections",
                    "Signage clearance",
                  ],
                  image:
                    "https://images.pexels.com/photos/15483696/pexels-photo-15483696.jpeg",
                },
                {
                  tag: "Industrial",
                  title: "Sector-Specific Licenses",
                  description:
                    "Manufacturing permits, industrial licensing, logistics authorizations, hospitality licenses, technology registrations, and healthcare certifications.",
                  benefits: [
                    "Industry expertise",
                    "Specialized permits",
                    "Regulatory compliance",
                    "Sector knowledge",
                  ],
                  image:
                    "https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg",
                },
                {
                  tag: "Residency",
                  title: "Premium Residency (SP1)",
                  description:
                    "Saudi Premium Residency Program support for entrepreneurs and investors. Eligibility assessment, pathway selection, and application processing.",
                  benefits: [
                    "Investor pathways",
                    "Eligibility assessment",
                    "Dossier preparation",
                    "Application support",
                  ],
                  image:
                    "https://images.pexels.com/photos/3184419/pexels-photo-3184419.jpeg",
                },
                {
                  tag: "Banking",
                  title: "Corporate Banking Setup",
                  description:
                    "Business bank account opening facilitation, banking relationship establishment, credit facility applications, and payment gateway setup.",
                  benefits: [
                    "Account opening",
                    "Banking relationships",
                    "Credit facilities",
                    "Payment solutions",
                  ],
                  image:
                    "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg",
                },
                {
                  tag: "PRO",
                  title: "Ongoing PRO Services",
                  description:
                    "Continuous government relations, license renewals, compliance monitoring, regulatory updates, and administrative support services.",
                  benefits: [
                    "Continuous support",
                    "License renewals",
                    "Compliance monitoring",
                    "Government relations",
                  ],
                  image:
                    "https://images.pexels.com/photos/7984742/pexels-photo-7984742.jpeg",
                },
                {
                  tag: "Legal",
                  title: "Legal Documentation",
                  description:
                    "Articles of Association drafting, contract preparation, legal translations, notarization services, and legal compliance consultation.",
                  benefits: [
                    "Legal drafting",
                    "Translations",
                    "Notarization",
                    "Compliance advice",
                  ],
                  image:
                    "https://images.pexels.com/photos/7641842/pexels-photo-7641842.jpeg",
                },
              ].map((service, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="relative h-40 overflow-hidden rounded-t-lg">
                    <img
                      src={service.image}
                      alt={`${service.title} service illustration`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                      <div className="p-4 text-white">
                        <span className="text-xs font-bold uppercase tracking-wider bg-coral px-2 py-1 rounded-full">
                          {service.tag}
                        </span>
                      </div>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl mb-2">
                      {service.title}
                    </CardTitle>
                    <p className="text-muted text-sm">{service.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <h4 className="font-semibold text-navy text-sm mb-2">
                        Key Benefits:
                      </h4>
                      <ul className="space-y-1">
                        {service.benefits.map((benefit, benefitIndex) => (
                          <li
                            key={benefitIndex}
                            className="flex items-center gap-2 text-xs"
                          >
                            <span className="w-1 h-1 bg-coral rounded-full"></span>
                            <span className="text-muted">{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <Button
                      size="sm"
                      asChild
                      className="w-full bg-navy text-white hover:bg-navy-600"
                    >
                      <Link to="/contact">Get Quote</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-8 p-6 bg-gradient-to-r from-navy to-navy-600 text-white rounded-2xl shadow-lg">
              <div className="text-center">
                <h3 className="text-xl font-bold mb-2">
                  <span className="text-accent">Custom Pricing:</span> Every
                  Business is Unique
                </h3>
                <p className="opacity-90">
                  We've removed all standard pricing because every engagement is
                  scoped and quoted based on your specific entity type, business
                  sector, timeline, and compliance requirements. Get a
                  transparent, itemized proposal tailored to your exact needs.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Industry Expertise with Photos */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Industry Expertise
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto mb-8">
                Specialized knowledge across key Saudi economic sectors with
                tailored compliance strategies. Our team understands the unique
                requirements and opportunities in each industry, ensuring your
                business setup aligns with sector-specific regulations and
                Vision 2030 objectives.
              </p>
              <div className="relative rounded-2xl overflow-hidden shadow-xl max-w-4xl mx-auto mb-8">
                <img
                  src="https://images.pexels.com/photos/30409999/pexels-photo-30409999.jpeg"
                  alt="Modern Riyadh cityscape representing diverse business opportunities"
                  className="w-full h-48 lg:h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/80 via-transparent to-transparent flex items-end">
                  <div className="p-6 text-white text-center w-full">
                    <h3 className="text-xl font-bold mb-2">
                      Diverse Sector Expertise
                    </h3>
                    <p className="text-sm opacity-90">
                      Serving major industries across Saudi Arabia's growing
                      economy
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Manufacturing & Industrial",
                  description:
                    "Factory setup, industrial licensing, localization plans, environmental permits, safety certifications, and equipment import facilitation.",
                  image:
                    "https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg",
                  sectors: [
                    "Heavy Manufacturing",
                    "Light Industry",
                    "Automotive",
                    "Chemicals",
                    "Food Processing",
                  ],
                },
                {
                  title: "Technology & Innovation",
                  description:
                    "SaaS licensing, fintech permits, cybersecurity approvals, e-commerce setup, data center permits, and intellectual property registration.",
                  image:
                    "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg",
                  sectors: [
                    "Software Development",
                    "Fintech",
                    "E-commerce",
                    "AI & Robotics",
                    "Telecommunications",
                  ],
                },
                {
                  title: "Logistics & Transportation",
                  description:
                    "Transport permits, warehouse licensing, bonded zone setup, customs facilitation, fleet registration, and supply chain optimization.",
                  image:
                    "https://images.pexels.com/photos/2226457/pexels-photo-2226457.jpeg",
                  sectors: [
                    "Freight & Cargo",
                    "Warehousing",
                    "Last-Mile Delivery",
                    "Cold Chain",
                    "Cross-Border Trade",
                  ],
                },
                {
                  title: "Hospitality & Tourism",
                  description:
                    "Hotel licensing, tourism permits, furnished apartment regulations, restaurant licenses, event permits, and cultural compliance.",
                  image:
                    "https://images.pexels.com/photos/14749879/pexels-photo-14749879.jpeg",
                  sectors: [
                    "Hotels & Resorts",
                    "Restaurants",
                    "Tourism Services",
                    "Event Management",
                    "Entertainment",
                  ],
                },
                {
                  title: "Healthcare & Pharmaceuticals",
                  description:
                    "Medical facility licensing, pharmaceutical permits, healthcare technology approvals, medical device imports, and MOH compliance.",
                  image:
                    "https://images.pexels.com/photos/236380/pexels-photo-236380.jpeg",
                  sectors: [
                    "Hospitals & Clinics",
                    "Pharmaceuticals",
                    "Medical Devices",
                    "Telemedicine",
                    "Health Tech",
                  ],
                },
                {
                  title: "Real Estate & Construction",
                  description:
                    "Development permits, construction licensing, property management setup, real estate brokerage, and urban planning compliance.",
                  image:
                    "https://images.pexels.com/photos/4161619/pexels-photo-4161619.jpeg",
                  sectors: [
                    "Residential Development",
                    "Commercial Real Estate",
                    "Construction",
                    "Property Management",
                    "Urban Planning",
                  ],
                },
              ].map((industry, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white hover:shadow-md transition-shadow"
                >
                  <div className="relative h-48 overflow-hidden rounded-t-lg">
                    <img
                      src={industry.image}
                      alt={`${industry.title} industry in Saudi Arabia`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                      <div className="p-4 text-white">
                        <h3 className="text-lg font-bold">{industry.title}</h3>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-muted text-sm mb-4">
                      {industry.description}
                    </p>
                    <div>
                      <h4 className="font-semibold text-navy text-sm mb-2">
                        Key Sectors:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {industry.sectors.map((sector, sectorIndex) => (
                          <span
                            key={sectorIndex}
                            className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                          >
                            {sector}
                          </span>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Process Excellence */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Our Proven Process
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto mb-8">
                Structured approach ensuring compliance, transparency, and
                timely delivery. Our methodology is refined through hundreds of
                successful business establishments across diverse sectors.
              </p>
              <div className="relative rounded-xl overflow-hidden shadow-lg max-w-2xl mx-auto mb-8">
                <img
                  src="https://images.pexels.com/photos/7984478/pexels-photo-7984478.jpeg"
                  alt="Professional business consultation and planning process"
                  className="w-full h-40 lg:h-48 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-coral/80 to-transparent flex items-center">
                  <div className="p-6 text-white">
                    <h3 className="text-lg font-bold">Structured Excellence</h3>
                    <p className="text-sm opacity-90">
                      From consultation to completion
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  step: "1",
                  title: "Discovery & Assessment",
                  description:
                    "Comprehensive evaluation of your business goals, sector requirements, regulatory landscape, timeline, and investment parameters. We conduct detailed feasibility analysis.",
                  duration: "1-2 weeks",
                  deliverables: [
                    "Feasibility Report",
                    "Timeline Planning",
                    "Cost Estimation",
                    "Risk Assessment",
                  ],
                },
                {
                  step: "2",
                  title: "Documentation & Legal Preparation",
                  description:
                    "Professional document drafting, certified translations, legal attestations, government portal preparation, and compliance framework establishment.",
                  duration: "2-3 weeks",
                  deliverables: [
                    "Legal Documents",
                    "Translations",
                    "Attestations",
                    "Applications",
                  ],
                },
                {
                  step: "3",
                  title: "Government Filing & Approvals",
                  description:
                    "Systematic filing with MISA, MoC, ZATCA, GOSI, municipalities, and sector-specific authorities. Professional follow-up and query resolution.",
                  duration: "3-6 weeks",
                  deliverables: [
                    "MISA License",
                    "CR Certificate",
                    "Tax Registration",
                    "Permits",
                  ],
                },
                {
                  step: "4",
                  title: "Operational Launch & Support",
                  description:
                    "Complete business setup finalization, operational readiness verification, ongoing compliance management, and continuous PRO support services.",
                  duration: "Ongoing",
                  deliverables: [
                    "Business Launch",
                    "Bank Accounts",
                    "Compliance Setup",
                    "PRO Services",
                  ],
                },
              ].map((process, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm text-center hover:shadow-md transition-shadow"
                >
                  <CardHeader>
                    <div className="w-12 h-12 bg-navy text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                      {process.step}
                    </div>
                    <CardTitle className="text-lg">{process.title}</CardTitle>
                    <div className="text-sm text-coral font-semibold">
                      {process.duration}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm mb-4">
                      {process.description}
                    </p>
                    <div>
                      <h4 className="font-semibold text-navy text-xs mb-2">
                        Key Deliverables:
                      </h4>
                      <ul className="space-y-1">
                        {process.deliverables.map((deliverable, delIndex) => (
                          <li
                            key={delIndex}
                            className="flex items-center justify-center gap-1 text-xs"
                          >
                            <span className="w-1 h-1 bg-coral rounded-full"></span>
                            <span className="text-muted">{deliverable}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Trust & Credibility Section */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Why Choose SafaArban
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Trusted by international companies for our expertise,
                transparency, and commitment to success.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <Card className="border-gray-200 shadow-sm bg-white text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-coral to-coral-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-white font-bold text-xl">200+</span>
                  </div>
                  <CardTitle className="text-lg">
                    Companies Established
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Successfully launched businesses across 25+ industry sectors
                  </p>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm bg-white text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-navy to-navy-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-white font-bold text-xl">98%</span>
                  </div>
                  <CardTitle className="text-lg">Success Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Consistent approval rates for MISA and CR applications
                  </p>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm bg-white text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-accent to-yellow-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-navy font-bold text-xl">30</span>
                  </div>
                  <CardTitle className="text-lg">Average Days</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    From initial consultation to operational business setup
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-gray-200 shadow-sm bg-white">
                <CardHeader>
                  <CardTitle className="text-lg">Expert Team</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Former MISA and government consultants with deep regulatory
                    knowledge and direct relationships with key authorities.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm bg-white">
                <CardHeader>
                  <CardTitle className="text-lg">Transparent Process</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Clear communication, itemized proposals, milestone-based
                    progress tracking, and no hidden fees or surprise charges.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm bg-white">
                <CardHeader>
                  <CardTitle className="text-lg">
                    Comprehensive Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Single point of contact managing the full lifecycle from
                    initial consultation to ongoing PRO services and compliance
                    management.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Success Stories Teaser */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Success Stories
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Real results from international companies who trusted SafaArban
                with their Saudi market entry.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-gray-200 shadow-sm">
                <div className="relative h-48 overflow-hidden rounded-t-lg">
                  <img
                    src="https://images.pexels.com/photos/3184419/pexels-photo-3184419.jpeg"
                    alt="Success story - international team celebration"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <h3 className="text-lg font-bold">
                        European Tech Company
                      </h3>
                      <p className="text-sm opacity-90">SaaS Platform Launch</p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-muted text-sm mb-4">
                    "SafaArban made our Saudi market entry seamless. From MISA
                    licensing to ZATCA compliance, their expertise saved us
                    months of delays and regulatory confusion."
                  </p>
                  <div className="text-xs text-coral font-semibold">
                    Timeline: 35 days | Sector: Technology | Entity: LLC
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm">
                <div className="relative h-48 overflow-hidden rounded-t-lg">
                  <img
                    src="https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg"
                    alt="Success story - manufacturing facility"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <h3 className="text-lg font-bold">
                        Asian Manufacturing Group
                      </h3>
                      <p className="text-sm opacity-90">
                        Industrial Facility Setup
                      </p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-muted text-sm mb-4">
                    "Complex industrial licensing made simple. SafaArban's
                    sector expertise and government relationships ensured our
                    manufacturing facility was operational ahead of schedule."
                  </p>
                  <div className="text-xs text-coral font-semibold">
                    Timeline: 45 days | Sector: Manufacturing | Entity: Branch
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-8">
              <Button
                variant="outline"
                asChild
                className="border-gray-300 text-navy hover:bg-gray-50"
              >
                <Link to="/about">View More Success Stories</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Enhanced CTA Section */}
        <section className="py-16 lg:py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
              Ready to Launch Your Saudi Business?
            </h2>
            <p className="text-lg text-muted mb-8">
              Join 200+ international companies who chose SafaArban for their
              Saudi market entry. Get a custom proposal tailored to your
              specific needs, timeline, and business objectives.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-coral mb-2">Free</div>
                <div className="text-sm text-muted">Initial Consultation</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-coral mb-2">24hr</div>
                <div className="text-sm text-muted">Response Time</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-coral mb-2">Custom</div>
                <div className="text-sm text-muted">Pricing Only</div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                asChild
                className="bg-navy text-white hover:bg-navy-600 shadow-lg"
              >
                <Link to="/contact">Request Custom Quote</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
                className="border-gray-300 text-navy hover:bg-gray-50"
              >
                <a
                  href="https://wa.me/966536182180"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Chat on WhatsApp
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
