import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CalendarDays, Clock3, Search, Sparkles, TrendingUp } from "lucide-react";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FeaturedPostCard } from "@/components/blog/FeaturedPostCard";
import { PostCard } from "@/components/blog/PostCard";
import { BlogPostMeta, extractPostMeta, parsePostDate } from "@/lib/blog";

const files = import.meta.glob("../articles/*.md", { query: "?raw", import: "default" });

const HERO_STATS = [
  { value: "80+", label: "Investment licenses accelerated" },
  { value: "6 weeks", label: "Average timeline saved" },
  { value: "12", label: "Industries we actively support" },
];

export default function Blog() {
  const [posts, setPosts] = useState<BlogPostMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("All Posts");
  const [searchTerm, setSearchTerm] = useState("");

  const pageTitle = "Saudi Business Insights & Regulatory Updates | SafaArban Blog";
  const pageDescription =
    "Expert insights on Saudi business regulations, MISA licensing, ZATCA compliance, Commercial Registration, and investment opportunities for foreign companies in Saudi Arabia.";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: origin ? `${origin}/` : undefined },
        { "@type": "ListItem", position: 2, name: "Blog", item: origin ? `${origin}/blog` : undefined },
      ],
    },
  ];

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const entries: BlogPostMeta[] = [];
      for (const path in files) {
        const loader = (files as Record<string, () => Promise<string>>)[path];
        const raw = await loader();
        const slug = path.split("/").pop()!.replace(/\.md$/, "");
        entries.push(extractPostMeta(slug, raw));
      }
      if (cancelled) return;
      entries.sort((a, b) => parsePostDate(b.date) - parsePostDate(a.date));
      setPosts(entries);
      setLoading(false);
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const categories = useMemo(() => {
    const set = new Set<string>(["All Posts"]);
    posts.forEach((post) => post.category && set.add(post.category));
    return Array.from(set);
  }, [posts]);

  const featuredPost = posts[0];
  const otherPosts = posts.slice(1);

  const filteredPosts = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return otherPosts.filter((post) => {
      const matchesCategory =
        activeCategory === "All Posts" || (post.category || "").toLowerCase() === activeCategory.toLowerCase();
      const matchesSearch =
        !term ||
        [post.title, post.excerpt, post.category]
          .filter(Boolean)
          .some((value) => value!.toLowerCase().includes(term));
      return matchesCategory && matchesSearch;
    });
  }, [otherPosts, activeCategory, searchTerm]);

  const trendingPosts = useMemo(() => otherPosts.slice(0, 3), [otherPosts]);

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={pageTitle}
        description={pageDescription}
        keywords={[
          "saudi business blog",
          "misa licensing guide",
          "zatca compliance",
          "commercial registration saudi",
          "premium residency sp1",
        ]}
        type="blog"
        jsonLd={jsonLd}
      />
      <Header />

      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-gray-50 via-white to-gray-100 py-16 lg:py-24">
          <div className="absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-coral-100/50 blur-3xl" />
          <div className="absolute -bottom-32 right-12 h-80 w-80 rounded-full bg-navy/10 blur-3xl" />
          <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
            <div className="grid items-center gap-10 lg:grid-cols-[3fr_2fr]">
              <div>
                <span className="inline-flex items-center gap-2 rounded-full bg-coral/10 px-4 py-1 text-sm text-coral">
                  <Sparkles className="h-4 w-4" />
                  SafaArban Knowledge Hub
                </span>
                <h1 className="mt-6 text-4xl font-bold tracking-tight text-navy lg:text-5xl">
                  In-depth Saudi business insights<br className="hidden sm:block" /> for decision makers
                </h1>
                <p className="mt-5 max-w-2xl text-lg text-muted">
                  Navigate licensing, compliance, and expansion in the Kingdom with practical playbooks from our advisory
                  team. Each insight is crafted from live engagements with international investors.
                </p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <Button asChild className="bg-navy text-white hover:bg-navy-600">
                    <Link to={featuredPost ? `/blog/${featuredPost.slug}` : "/blog"}>Read the latest insight</Link>
                  </Button>
                  <Button asChild variant="outline" className="border-gray-300 text-navy hover:bg-gray-50">
                    <Link to="/contact">Talk to an advisor</Link>
                  </Button>
                </div>
                <div className="mt-10 grid gap-4 sm:grid-cols-3">
                  {HERO_STATS.map((stat) => (
                    <div key={stat.label} className="rounded-2xl border border-white/60 bg-white/60 p-6 shadow-sm backdrop-blur">
                      <p className="text-3xl font-semibold text-navy">{stat.value}</p>
                      <p className="mt-2 text-sm text-muted">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
              <Card className="border-none bg-white/90 shadow-lg backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-navy">What&apos;s inside our briefings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 text-sm text-muted">
                  <div className="rounded-lg border border-gray-200 bg-white/80 p-4 shadow-sm">
                    <p className="font-medium text-navy">Step-by-step licensing guides</p>
                    <p className="mt-2 text-xs">
                      Clear documentation, sequencing, and stakeholder requirements across MISA, CR, ZATCA, and sector regulators.
                    </p>
                  </div>
                  <div className="rounded-lg border border-gray-200 bg-white/80 p-4 shadow-sm">
                    <p className="font-medium text-navy">Market-tested frameworks</p>
                    <p className="mt-2 text-xs">Insights distilled from engagements with multinational and regional investors in Saudi Arabia.</p>
                  </div>
                  <div className="rounded-lg border border-gray-200 bg-white/80 p-4 shadow-sm">
                    <p className="font-medium text-navy">Compliance timelines &amp; costs</p>
                    <p className="mt-2 text-xs">Compare processing routes, fees, and submission checklists to build confident expansion plans.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {featuredPost && (
          <section className="py-16 lg:py-20">
            <div className="mx-auto max-w-6xl px-4 sm:px-6">
              <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-navy">Featured insight</h2>
                  <p className="text-sm text-muted">A deep-dive picked by our strategy team this month.</p>
                </div>
                <Button asChild variant="ghost" className="text-sm text-coral hover:text-coral">
                  <Link to="/blog">Browse all articles</Link>
                </Button>
              </div>
              <FeaturedPostCard post={featuredPost} />
            </div>
          </section>
        )}

        <section id="latest" className="bg-gray-50 py-16 lg:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="grid gap-12 lg:grid-cols-[3fr_1fr]">
              <div>
                <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                  <div className="flex w-full items-center gap-3 overflow-x-auto pb-1 md:w-auto">
                    {categories.map((category) => {
                      const isActive = activeCategory === category;
                      return (
                        <Button
                          key={category}
                          variant={isActive ? "default" : "outline"}
                          size="sm"
                          className={
                            isActive
                              ? "bg-navy text-white hover:bg-navy-600"
                              : "border-gray-300 text-navy hover:bg-white"
                          }
                          aria-pressed={isActive}
                          onClick={() => setActiveCategory(category)}
                        >
                          {category}
                        </Button>
                      );
                    })}
                  </div>
                  <div className="relative w-full md:max-w-xs">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                    <Input
                      value={searchTerm}
                      onChange={(event) => setSearchTerm(event.target.value)}
                      placeholder="Search insights..."
                      className="pl-9"
                      type="search"
                    />
                  </div>
                </div>

                <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                  {loading && posts.length === 0 ? (
                    Array.from({ length: 3 }).map((_, index) => (
                      <Card key={index} className="h-64 animate-pulse border-gray-200 bg-white/60" />
                    ))
                  ) : filteredPosts.length > 0 ? (
                    filteredPosts.map((post) => <PostCard key={post.slug} post={post} />)
                  ) : (
                    <Card className="col-span-full border-gray-200 bg-white/70 p-10 text-center shadow-sm">
                      <CardContent className="space-y-3 p-0">
                        <h3 className="text-xl font-semibold text-navy">No insights match your filters yet</h3>
                        <p className="text-sm text-muted">
                          Adjust the category or search term, or reach out to our advisors for tailored guidance.
                        </p>
                        <Button asChild variant="outline" className="border-gray-300 text-navy hover:bg-white">
                          <Link to="/contact">Request a briefing</Link>
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>

              <aside className="space-y-6">
                <Card className="border-gray-200 shadow-sm">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-coral" />
                      <CardTitle className="text-base font-semibold text-navy">Trending this quarter</CardTitle>
                    </div>
                    <p className="text-xs text-muted">
                      Frequently referenced insights across licensing, employment, and compliance.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-5">
                      {trendingPosts.length === 0 ? (
                        <li className="text-sm text-muted">Articles will appear here as soon as they are published.</li>
                      ) : (
                        trendingPosts.map((post, index) => (
                          <li key={post.slug} className="flex items-start gap-3">
                            <span className="text-sm font-semibold text-navy/60">{String(index + 1).padStart(2, "0")}</span>
                            <div className="space-y-1">
                              <Link
                                to={`/blog/${post.slug}`}
                                className="text-sm font-semibold text-navy hover:text-coral"
                              >
                                {post.title}
                              </Link>
                              <div className="flex flex-wrap items-center gap-3 text-xs text-muted">
                                {post.date && (
                                  <span className="inline-flex items-center gap-1">
                                    <CalendarDays className="h-3.5 w-3.5" />
                                    {post.date}
                                  </span>
                                )}
                                {post.readTime && (
                                  <span className="inline-flex items-center gap-1">
                                    <Clock3 className="h-3.5 w-3.5" />
                                    {post.readTime}
                                  </span>
                                )}
                              </div>
                            </div>
                          </li>
                        ))
                      )}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-gray-200 bg-white shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-base font-semibold text-navy">Stay ahead with monthly briefings</CardTitle>
                    <p className="text-xs text-muted">
                      We send one email each month summarizing regulatory shifts, upcoming deadlines, and investor-friendly policy changes.
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button asChild className="w-full bg-navy text-white hover:bg-navy-600">
                      <Link to="/contact">Subscribe to updates</Link>
                    </Button>
                    <Button asChild variant="link" className="w-full text-coral">
                      <Link to="/contact">Book a strategy call →</Link>
                    </Button>
                  </CardContent>
                </Card>
              </aside>
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
            <h2 className="text-3xl font-bold text-navy">Need bespoke market entry support?</h2>
            <p className="mt-4 text-lg text-muted">
              Our consultants partner with investors to navigate licensing and compliance end-to-end, from feasibility to operational launch.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button asChild className="bg-navy text-white hover:bg-navy-600">
                <Link to="/contact">Request a consultation</Link>
              </Button>
              <Button asChild variant="outline" className="border-gray-300 text-navy hover:bg-gray-50">
                <Link to="/about">Meet the team</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
