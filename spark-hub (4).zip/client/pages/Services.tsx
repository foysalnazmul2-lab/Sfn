import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function Services() {
  const pageTitle =
    "Saudi Business Services - MISA Licensing, CR Registration & Compliance | SafaArban";
  const pageDescription =
    "Comprehensive Saudi business services: MISA investment licensing, Commercial Registration, ZATCA compliance, GOSI registration, municipality permits, and sector-specific licensing for foreign companies.";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: origin ? `${origin}/` : undefined },
        { "@type": "ListItem", position: 2, name: "Services", item: origin ? `${origin}/services` : undefined },
      ],
    },
  ];

  const coreServices = [
    {
      category: "MISA Licensing",
      title: "Investment License",
      description:
        "Complete MISA investment license preparation and filing for 100% foreign-owned entities with expert guidance through the entire process.",
      image:
        "https://images.pexels.com/photos/7641842/pexels-photo-7641842.jpeg",
      timeline: "20-30 business days",
      complexity: "High",
      details: [
        "Eligibility assessment and documentation requirements analysis",
        "Legal document preparation and certified Arabic translation",
        "MISA portal filing and application submission management",
        "Government follow-up and approval coordination",
        "License issuance and certificate delivery",
      ],
      benefits: [
        "Legal authorization for foreign business operations",
        "Government backing and investment protection",
        "Access to Saudi Arabia's growing economy",
        "Foundation for all subsequent business registrations",
        "Compliance with Vision 2030 investment framework",
      ],
      sectors: [
        "All eligible sectors",
        "Manufacturing",
        "Technology",
        "Services",
        "Healthcare",
        "Logistics",
      ],
    },
    {
      category: "Company Formation",
      title: "Commercial Registration (CR)",
      description:
        "End-to-end company formation including all legal and regulatory requirements for business establishment in Saudi Arabia.",
      image:
        "https://images.pexels.com/photos/7641842/pexels-photo-7641842.jpeg",
      timeline: "15-25 business days",
      complexity: "Medium",
      details: [
        "Articles of Association drafting and legal structuring",
        "Notarization and legal attestation coordination",
        "Commercial Registration issuance and processing",
        "Chamber of Commerce registration and sealing",
        "Corporate identity establishment and documentation",
      ],
      benefits: [
        "Legal business entity establishment in Saudi Arabia",
        "Authorization for commercial activities and operations",
        "Banking relationship facilitation and account opening",
        "Tax registration and compliance foundation",
        "Government services access and business credibility",
      ],
      sectors: [
        "LLC",
        "Branch Office",
        "Joint Stock Company",
        "Representative Office",
      ],
    },
    {
      category: "Tax & Compliance",
      title: "ZATCA, GOSI & Qiwa Registration",
      description:
        "Complete tax registration, social insurance setup, and e-invoicing implementation for full regulatory compliance.",
      image:
        "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg",
      timeline: "10-15 business days",
      complexity: "Medium",
      details: [
        "ZATCA tax and VAT registration and setup",
        "GOSI social insurance registration for employees",
        "Qiwa platform setup and Saudization planning",
        "E-invoicing system implementation and integration",
        "Ongoing compliance monitoring and reporting",
      ],
      benefits: [
        "Full tax compliance and regulatory adherence",
        "Employee social insurance coverage and protection",
        "Automated e-invoicing and reduced administrative burden",
        "Saudization planning and Nitaqat compliance",
        "Government services integration and streamlined operations",
      ],
      sectors: [
        "All registered businesses",
        "Employers",
        "VAT-eligible entities",
      ],
    },
    {
      category: "Municipal Licensing",
      title: "Municipality Permits & Approvals",
      description:
        "Location-specific municipal permits and activity-specific licensing for operational compliance.",
      image:
        "https://images.pexels.com/photos/15483696/pexels-photo-15483696.jpeg",
      timeline: "7-14 business days",
      complexity: "Low-Medium",
      details: [
        "Municipal activity mapping and classification",
        "Site inspection preparation and coordination",
        "Signage and branding approvals and permits",
        "Health and safety clearances and certifications",
        "Environmental compliance and waste management permits",
      ],
      benefits: [
        "Legal operation authorization at specific locations",
        "Health and safety compliance certification",
        "Signage and branding permission for visibility",
        "Environmental compliance and community acceptance",
        "Operational readiness and customer service capability",
      ],
      sectors: [
        "Retail",
        "Restaurants",
        "Manufacturing",
        "Healthcare",
        "Education",
      ],
    },
    {
      category: "Industrial Licensing",
      title: "Manufacturing & Industrial Permits",
      description:
        "Comprehensive industrial licensing for manufacturing facilities, factories, and production operations.",
      image:
        "https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg",
      timeline: "30-60 business days",
      complexity: "High",
      details: [
        "Industrial license applications and processing",
        "Factory permits and production authorizations",
        "Environmental impact assessments and approvals",
        "Safety and health compliance certifications",
        "Equipment import permits and customs facilitation",
      ],
      benefits: [
        "Manufacturing and production authorization",
        "Environmental compliance and sustainability certification",
        "Safety standards adherence and worker protection",
        "Equipment import facilitation and cost savings",
        "Industrial zone access and infrastructure benefits",
      ],
      sectors: [
        "Heavy Industry",
        "Light Manufacturing",
        "Food Processing",
        "Chemicals",
        "Textiles",
      ],
    },
    {
      category: "Technology Licensing",
      title: "Tech & Innovation Permits",
      description:
        "Specialized licensing for technology companies, software development, and innovation-driven businesses.",
      image:
        "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg",
      timeline: "15-30 business days",
      complexity: "Medium-High",
      details: [
        "Software licensing and intellectual property registration",
        "Data protection compliance and cybersecurity approvals",
        "Fintech permits and financial service authorizations",
        "E-commerce platform setup and payment gateway licensing",
        "Telecommunications and connectivity service permits",
      ],
      benefits: [
        "Technology innovation authorization and protection",
        "Data security compliance and customer trust",
        "Financial service capabilities and payment processing",
        "E-commerce operations and online business growth",
        "Telecommunications infrastructure access and connectivity",
      ],
      sectors: [
        "SaaS",
        "Fintech",
        "E-commerce",
        "Telecommunications",
        "Cybersecurity",
      ],
    },
    {
      category: "Hospitality Licensing",
      title: "Tourism & Hospitality Permits",
      description:
        "Hotel licensing, tourism permits, and hospitality sector regulatory compliance and certifications.",
      image:
        "https://images.pexels.com/photos/14749879/pexels-photo-14749879.jpeg",
      timeline: "20-40 business days",
      complexity: "Medium-High",
      details: [
        "Hotel and accommodation licensing and classifications",
        "Tourism authority permits and destination approvals",
        "Restaurant and food service licensing and health permits",
        "Event management permits and entertainment licenses",
        "Cultural compliance and heritage site access approvals",
      ],
      benefits: [
        "Hospitality operations authorization and guest services",
        "Tourism industry access and destination marketing",
        "Food service capabilities and customer dining experiences",
        "Event hosting authorization and entertainment offerings",
        "Cultural integration and authentic experience delivery",
      ],
      sectors: [
        "Hotels",
        "Restaurants",
        "Tourism Services",
        "Event Management",
        "Entertainment",
      ],
    },
    {
      category: "Healthcare Licensing",
      title: "Medical & Healthcare Permits",
      description:
        "Medical facility licensing, pharmaceutical permits, and healthcare sector regulatory compliance.",
      image: "https://images.pexels.com/photos/236380/pexels-photo-236380.jpeg",
      timeline: "30-45 business days",
      complexity: "High",
      details: [
        "Medical facility licensing and accreditation processes",
        "Pharmaceutical import permits and drug registration",
        "Healthcare professional licensing and certification",
        "Medical device import and distribution permits",
        "Ministry of Health approvals and compliance certifications",
      ],
      benefits: [
        "Healthcare service delivery authorization and patient care",
        "Pharmaceutical operations and medication distribution",
        "Professional practice authorization and career development",
        "Medical technology access and patient treatment options",
        "Government healthcare integration and insurance acceptance",
      ],
      sectors: [
        "Hospitals",
        "Clinics",
        "Pharmaceuticals",
        "Medical Devices",
        "Telemedicine",
      ],
    },
    {
      category: "Logistics Licensing",
      title: "Transportation & Logistics Permits",
      description:
        "Comprehensive logistics licensing including warehousing, transportation, and customs facilitation.",
      image:
        "https://images.pexels.com/photos/2226457/pexels-photo-2226457.jpeg",
      timeline: "15-25 business days",
      complexity: "Medium",
      details: [
        "Transport permits and vehicle fleet registration",
        "Warehouse licensing and storage facility approvals",
        "Bonded zone setup and customs facilitation services",
        "Freight and cargo handling permits and certifications",
        "Cross-border trade facilitation and corridor access",
      ],
      benefits: [
        "Transportation operations and fleet management capabilities",
        "Warehousing and storage services for inventory management",
        "Customs facilitation and reduced import/export costs",
        "Freight operations and cargo handling efficiency",
        "Regional trade access and cross-border business opportunities",
      ],
      sectors: [
        "Freight",
        "Warehousing",
        "Last-Mile Delivery",
        "Cross-Border Trade",
        "Cold Chain",
      ],
    },
    {
      category: "Real Estate Licensing",
      title: "Property & Development Permits",
      description:
        "Real estate development permits, construction licensing, and property management regulatory setup.",
      image:
        "https://images.pexels.com/photos/4161619/pexels-photo-4161619.jpeg",
      timeline: "25-45 business days",
      complexity: "High",
      details: [
        "Real estate development permits and planning approvals",
        "Construction licensing and building permit processing",
        "Property management licensing and service authorizations",
        "Real estate brokerage permits and transaction facilitation",
        "Urban planning compliance and zoning approvals",
      ],
      benefits: [
        "Real estate development and construction authorization",
        "Property management services and rental operations",
        "Real estate transaction facilitation and brokerage services",
        "Urban development participation and community building",
        "Investment opportunities and property portfolio growth",
      ],
      sectors: [
        "Residential Development",
        "Commercial Real Estate",
        "Construction",
        "Property Management",
      ],
    },
    {
      category: "Premium Residency",
      title: "Saudi Premium Residency (SP1)",
      description:
        "Complete support for Saudi Premium Residency Program for entrepreneurs and investors.",
      image:
        "https://images.pexels.com/photos/3184419/pexels-photo-3184419.jpeg",
      timeline: "60-90 business days",
      complexity: "High",
      details: [
        "Eligibility assessment and pathway selection guidance",
        "Investment dossier preparation and financial documentation",
        "Application submission and government liaison coordination",
        "Interview preparation and presentation support",
        "Residency card processing and delivery coordination",
      ],
      benefits: [
        "Long-term residency and stability for entrepreneurs",
        "Investment protection and business continuity assurance",
        "Family residency inclusion and lifestyle benefits",
        "Enhanced business credibility and market access",
        "Government services access and community integration",
      ],
      sectors: [
        "Entrepreneurs",
        "Investors",
        "Business Owners",
        "Professionals",
      ],
    },
    {
      category: "Banking & Finance",
      title: "Corporate Banking & Financial Services",
      description:
        "Business bank account opening facilitation and corporate financial services coordination.",
      image:
        "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg",
      timeline: "5-10 business days",
      complexity: "Low-Medium",
      details: [
        "Bank selection and relationship establishment guidance",
        "Corporate account opening documentation and processing",
        "Credit facility applications and financial product access",
        "Payment gateway setup and merchant services coordination",
        "International banking and trade finance facilitation",
      ],
      benefits: [
        "Banking relationships and financial service access",
        "Payment processing capabilities and transaction efficiency",
        "Credit facilities and business financing options",
        "International trade facilitation and currency management",
        "Financial compliance and regulatory adherence",
      ],
      sectors: [
        "All business entities",
        "Import/Export companies",
        "E-commerce",
      ],
    },
    {
      category: "Ongoing Support",
      title: "PRO & Compliance Management",
      description:
        "Continuous government relations and compliance management services for sustained operations.",
      image:
        "https://images.pexels.com/photos/7984742/pexels-photo-7984742.jpeg",
      timeline: "Ongoing monthly",
      complexity: "Medium",
      details: [
        "Monthly compliance monitoring and status reporting",
        "Government correspondence handling and communication",
        "License renewals and regulatory update management",
        "Employee visa processing and HR compliance support",
        "Business expansion support and additional licensing",
      ],
      benefits: [
        "Continuous compliance assurance and risk management",
        "Government relations maintenance and communication",
        "License validity and renewal management",
        "HR compliance and employee documentation management",
        "Business growth support and expansion facilitation",
      ],
      sectors: [
        "All established businesses",
        "Growing companies",
        "Multi-location operations",
      ],
    },
  ];

  const additionalServices = [
    {
      title: "Legal Documentation & Translation",
      description:
        "Professional legal document preparation, certified translations, and notarization services.",
      features: [
        "Articles of Association drafting",
        "Contract preparation",
        "Certified Arabic translations",
        "Notarization coordination",
      ],
    },
    {
      title: "Business Consulting & Advisory",
      description:
        "Strategic business consulting for market entry, expansion, and regulatory compliance.",
      features: [
        "Market entry strategy",
        "Regulatory compliance advice",
        "Business structure optimization",
        "Risk assessment and mitigation",
      ],
    },
    {
      title: "Government Relations & Liaison",
      description:
        "Professional government relations and official correspondence management services.",
      features: [
        "Government liaison services",
        "Official correspondence",
        "Regulatory updates",
        "Policy change notifications",
      ],
    },
    {
      title: "Training & Capacity Building",
      description:
        "Employee training programs and capacity building for regulatory compliance and business operations.",
      features: [
        "Compliance training",
        "HR management training",
        "Government portal training",
        "Business process optimization",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={pageTitle}
        description={pageDescription}
        keywords={[
          "saudi business services",
          "misa licensing",
          "commercial registration",
          "zatca gosi qiwa",
          "municipality permits",
          "industrial licensing",
        ]}
        type="website"
        jsonLd={jsonLd}
      />
      <Header />

      <main>
        {/* Enhanced Hero Section */}
        <section className="bg-gradient-to-b from-gray-50/60 to-white py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-8">
              <h1 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
                Complete Saudi Business Formation & Licensing Services
              </h1>
              <p className="text-xl text-muted max-w-3xl mx-auto mb-8">
                From MISA investment licensing and Commercial Registration to
                ZATCA e-invoicing compliance — we provide comprehensive business
                setup and regulatory compliance services for 100% foreign-owned
                companies in Saudi Arabia, supporting Vision 2030 investment
                opportunities.
              </p>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-coral-50 border border-dashed border-coral-200 rounded-full text-coral font-semibold">
                <span className="w-2 h-2 bg-coral rounded-full"></span>
                Custom pricing only — no standard packages
              </div>
            </div>

            {/* Services Hero Image */}
            <div className="relative rounded-2xl overflow-hidden shadow-xl max-w-4xl mx-auto">
              <img
                src="https://images.pexels.com/photos/8441784/pexels-photo-8441784.jpeg"
                alt="Professional business consulting and document signing services"
                className="w-full h-48 lg:h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-navy/80 to-transparent flex items-center">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-2">
                    Comprehensive Service Portfolio
                  </h3>
                  <p className="text-sm opacity-90">
                    End-to-end business setup and compliance solutions
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Service Categories Overview */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Service Categories
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Organized service portfolio covering every aspect of business
                establishment and operations in Saudi Arabia.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  category: "Core Setup",
                  services: [
                    "MISA Licensing",
                    "Commercial Registration",
                    "Tax Registration",
                  ],
                  icon: "📋",
                },
                {
                  category: "Compliance",
                  services: [
                    "ZATCA E-invoicing",
                    "GOSI Registration",
                    "Municipality Permits",
                  ],
                  icon: "✅",
                },
                {
                  category: "Sector-Specific",
                  services: [
                    "Industrial Licensing",
                    "Technology Permits",
                    "Healthcare Licensing",
                  ],
                  icon: "🏭",
                },
                {
                  category: "Ongoing Support",
                  services: [
                    "PRO Services",
                    "Compliance Management",
                    "Government Relations",
                  ],
                  icon: "🤝",
                },
              ].map((category, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white text-center"
                >
                  <CardHeader>
                    <div className="text-4xl mb-4">{category.icon}</div>
                    <CardTitle className="text-lg">
                      {category.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {category.services.map((service, serviceIndex) => (
                        <li key={serviceIndex} className="text-sm text-muted">
                          {service}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Comprehensive Services Grid */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Complete Service Portfolio
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Detailed breakdown of all services with timelines, complexity
                levels, and comprehensive benefits.
              </p>
            </div>

            <div className="space-y-8">
              {coreServices.map((service, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="grid lg:grid-cols-3 gap-0">
                    {/* Service Image */}
                    <div className="relative h-64 lg:h-auto overflow-hidden lg:rounded-l-lg">
                      <img
                        src={service.image}
                        alt={`${service.title} - professional Saudi business service`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                        <div className="p-6 text-white">
                          <span className="text-xs font-bold uppercase tracking-wider bg-coral px-2 py-1 rounded-full mb-2 inline-block">
                            {service.category}
                          </span>
                          <h3 className="text-xl font-bold">{service.title}</h3>
                        </div>
                      </div>
                    </div>

                    {/* Service Details */}
                    <div className="lg:col-span-2 p-6">
                      <div className="flex flex-wrap gap-4 mb-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-navy">
                            Timeline:
                          </span>
                          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            {service.timeline}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-navy">
                            Complexity:
                          </span>
                          <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">
                            {service.complexity}
                          </span>
                        </div>
                      </div>

                      <p className="text-muted mb-6">{service.description}</p>

                      <div className="grid md:grid-cols-2 gap-6">
                        {/* Service Details */}
                        <div>
                          <h4 className="font-semibold text-navy mb-3">
                            Service Includes:
                          </h4>
                          <ul className="space-y-2">
                            {service.details.map((detail, detailIndex) => (
                              <li
                                key={detailIndex}
                                className="flex items-start gap-2 text-sm"
                              >
                                <span className="w-1.5 h-1.5 bg-coral rounded-full mt-2 flex-shrink-0"></span>
                                <span className="text-muted">{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Benefits */}
                        <div>
                          <h4 className="font-semibold text-navy mb-3">
                            Key Benefits:
                          </h4>
                          <ul className="space-y-2">
                            {service.benefits.map((benefit, benefitIndex) => (
                              <li
                                key={benefitIndex}
                                className="flex items-start gap-2 text-sm"
                              >
                                <span className="w-1.5 h-1.5 bg-accent rounded-full mt-2 flex-shrink-0"></span>
                                <span className="text-muted">{benefit}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Applicable Sectors */}
                      <div className="mt-6">
                        <h4 className="font-semibold text-navy mb-2">
                          Applicable Sectors:
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {service.sectors.map((sector, sectorIndex) => (
                            <span
                              key={sectorIndex}
                              className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                            >
                              {sector}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mt-6">
                        <Button
                          asChild
                          className="bg-navy text-white hover:bg-navy-600"
                        >
                          <Link to="/contact">Request Detailed Quote</Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Additional Services */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Additional Professional Services
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Supporting services that complement our core offerings for
                complete business success.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {additionalServices.map((service, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white"
                >
                  <CardHeader>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                    <p className="text-muted">{service.description}</p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li
                          key={featureIndex}
                          className="flex items-start gap-2 text-sm"
                        >
                          <span className="w-1.5 h-1.5 bg-coral rounded-full mt-2 flex-shrink-0"></span>
                          <span className="text-muted">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Service Methodology */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Our Service Methodology
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Proven approach refined through hundreds of successful business
                establishments.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  step: "1",
                  title: "Comprehensive Assessment",
                  description:
                    "Detailed analysis of your business requirements, sector regulations, and compliance needs.",
                  duration: "2-3 days",
                },
                {
                  step: "2",
                  title: "Strategic Planning",
                  description:
                    "Custom roadmap creation with timelines, milestones, and resource allocation.",
                  duration: "3-5 days",
                },
                {
                  step: "3",
                  title: "Document Preparation",
                  description:
                    "Professional document drafting, translations, and attestation coordination.",
                  duration: "1-2 weeks",
                },
                {
                  step: "4",
                  title: "Government Processing",
                  description:
                    "Systematic filing, follow-up, and approval management with all authorities.",
                  duration: "2-6 weeks",
                },
              ].map((phase, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm text-center"
                >
                  <CardHeader>
                    <div className="w-12 h-12 bg-navy text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                      {phase.step}
                    </div>
                    <CardTitle className="text-lg">{phase.title}</CardTitle>
                    <div className="text-sm text-coral font-semibold">
                      {phase.duration}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm">{phase.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Philosophy */}
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="bg-gradient-to-r from-navy to-navy-600 text-white rounded-2xl p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">
                Why We Don't Display Standard Pricing
              </h3>
              <p className="text-lg opacity-90 mb-6">
                Every business setup is unique with different sector
                requirements, entity types, timelines, and compliance needs. Our
                pricing reflects the actual scope of work required for your
                specific situation, ensuring you pay only for services you need.
              </p>
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    Custom
                  </div>
                  <div className="text-sm opacity-90">Scope Assessment</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    Transparent
                  </div>
                  <div className="text-sm opacity-90">Itemized Proposals</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    No Hidden
                  </div>
                  <div className="text-sm opacity-90">Fees or Surprises</div>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  variant="secondary"
                  asChild
                  className="bg-white text-navy hover:bg-gray-50"
                >
                  <Link to="/contact">Get Your Custom Quote</Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  asChild
                  className="border-white text-white hover:bg-white/10"
                >
                  <a
                    href="https://wa.me/966536182180"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Chat on WhatsApp
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
