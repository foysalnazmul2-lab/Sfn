import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function MisaLicensing() {
  const pageTitle =
    "MISA Investment License Services - Expert Saudi Business Licensing | SafaArban";
  const pageDescription =
    "Professional MISA investment license services for 100% foreign-owned companies in Saudi Arabia. Expert guidance, document preparation, and government liaison for successful approvals.";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: origin ? `${origin}/` : undefined },
        { "@type": "ListItem", position: 2, name: "Services", item: origin ? `${origin}/services` : undefined },
        { "@type": "ListItem", position: 3, name: "MISA Investment License", item: origin ? `${origin}/services/misa-licensing` : undefined },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={pageTitle}
        description={pageDescription}
        keywords={[
          "misa investment license",
          "saudi license for foreign company",
          "misa consultant",
          "saudi business licensing",
        ]}
        type="website"
        jsonLd={jsonLd}
      />
      <Header />

      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-gray-50/60 to-white py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block mb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-navy bg-blue-50 px-3 py-1 rounded-full">
                    MISA Investment Licensing Specialists
                  </span>
                </div>
                <h1 className="text-4xl lg:text-5xl font-bold text-navy leading-tight mb-6">
                  Expert MISA Investment License Services for{" "}
                  <span className="text-coral">100% Foreign Ownership</span>
                </h1>
                <p className="text-lg text-muted mb-8">
                  Professional MISA investment license processing with 98%
                  success rate. Our former MISA consultants provide expert
                  guidance, complete document preparation, and direct government
                  liaison for efficient approvals.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <Button
                    size="lg"
                    asChild
                    className="bg-navy text-white hover:bg-navy-600 shadow-lg"
                  >
                    <Link to="/contact">Get MISA License Quote</Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    asChild
                    className="border-gray-300 text-navy hover:bg-gray-50"
                  >
                    <a
                      href="https://wa.me/966536182180"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      WhatsApp Consultation
                    </a>
                  </Button>
                </div>
                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-coral rounded-full"></span>
                    <span className="text-muted">20-30 day processing</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-coral rounded-full"></span>
                    <span className="text-muted">98% success rate</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-coral rounded-full"></span>
                    <span className="text-muted">Expert guidance</span>
                  </div>
                </div>
              </div>

              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.pexels.com/photos/7641842/pexels-photo-7641842.jpeg"
                  alt="MISA investment license documentation and professional services"
                  className="w-full h-80 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/80 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-xl font-bold mb-2">
                      Professional MISA Services
                    </h3>
                    <p className="text-sm opacity-90">
                      Expert guidance for successful investment licensing
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Service Benefits */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Why Choose Our MISA Services
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Comprehensive investment licensing services with insider
                expertise and proven track record.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Former MISA Consultants",
                  description:
                    "Our team includes former MISA staff with direct experience in investment licensing and government relations.",
                  icon: "👥",
                  benefits: [
                    "Insider knowledge",
                    "Direct relationships",
                    "Process expertise",
                    "Efficient processing",
                  ],
                },
                {
                  title: "98% Success Rate",
                  description:
                    "Proven track record with consistent approval rates across diverse sectors and investment types.",
                  icon: "📈",
                  benefits: [
                    "High success rate",
                    "Risk mitigation",
                    "Quality assurance",
                    "Proven methodology",
                  ],
                },
                {
                  title: "20-30 Day Processing",
                  description:
                    "Streamlined processing with efficient document preparation and proactive government liaison.",
                  icon: "⚡",
                  benefits: [
                    "Fast processing",
                    "Timeline adherence",
                    "Proactive management",
                    "Regular updates",
                  ],
                },
                {
                  title: "Complete Documentation",
                  description:
                    "Professional document preparation, certified translations, and attestation coordination.",
                  icon: "📋",
                  benefits: [
                    "Document drafting",
                    "Certified translations",
                    "Attestation services",
                    "Quality control",
                  ],
                },
                {
                  title: "Sector Expertise",
                  description:
                    "Specialized knowledge across 25+ industry sectors with tailored licensing strategies.",
                  icon: "🏭",
                  benefits: [
                    "Industry knowledge",
                    "Sector requirements",
                    "Compliance expertise",
                    "Strategic guidance",
                  ],
                },
                {
                  title: "Transparent Pricing",
                  description:
                    "Custom pricing with itemized proposals and no hidden fees or surprise charges.",
                  icon: "💎",
                  benefits: [
                    "Custom quotes",
                    "Transparent fees",
                    "No hidden costs",
                    "Value for money",
                  ],
                },
              ].map((benefit, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                >
                  <CardHeader>
                    <div className="text-4xl mb-4">{benefit.icon}</div>
                    <CardTitle className="text-xl">{benefit.title}</CardTitle>
                    <p className="text-muted">{benefit.description}</p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {benefit.benefits.map((item, itemIndex) => (
                        <li
                          key={itemIndex}
                          className="flex items-center gap-2 text-sm"
                        >
                          <span className="w-1.5 h-1.5 bg-coral rounded-full"></span>
                          <span className="text-muted">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Service Process */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Our MISA Licensing Process
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Structured approach refined through hundreds of successful MISA
                license applications.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  step: "1",
                  title: "Eligibility Assessment",
                  description:
                    "Comprehensive evaluation of investment eligibility, sector requirements, and documentation needs.",
                  duration: "2-3 days",
                  activities: [
                    "Investment analysis",
                    "Sector compliance",
                    "Document checklist",
                    "Timeline planning",
                  ],
                },
                {
                  step: "2",
                  title: "Document Preparation",
                  description:
                    "Professional document drafting, certified translations, and legal attestation coordination.",
                  duration: "1-2 weeks",
                  activities: [
                    "Document drafting",
                    "Translation services",
                    "Legal attestation",
                    "Quality review",
                  ],
                },
                {
                  step: "3",
                  title: "MISA Submission",
                  description:
                    "Strategic application filing with MISA portal and comprehensive government liaison.",
                  duration: "1 week",
                  activities: [
                    "Portal filing",
                    "Document submission",
                    "Initial review",
                    "Query response",
                  ],
                },
                {
                  step: "4",
                  title: "Approval & Delivery",
                  description:
                    "Government processing management, approval coordination, and license delivery.",
                  duration: "2-3 weeks",
                  activities: [
                    "Processing follow-up",
                    "Approval coordination",
                    "License issuance",
                    "Certificate delivery",
                  ],
                },
              ].map((phase, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white"
                >
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-coral text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                      {phase.step}
                    </div>
                    <CardTitle className="text-lg">{phase.title}</CardTitle>
                    <div className="text-sm text-navy font-semibold">
                      {phase.duration}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm mb-4">
                      {phase.description}
                    </p>
                    <div>
                      <h4 className="font-semibold text-navy text-xs mb-2">
                        Key Activities:
                      </h4>
                      <ul className="space-y-1">
                        {phase.activities.map((activity, actIndex) => (
                          <li
                            key={actIndex}
                            className="flex items-center gap-2 text-xs"
                          >
                            <span className="w-1 h-1 bg-coral rounded-full"></span>
                            <span className="text-muted">{activity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Eligible Sectors */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Eligible Investment Sectors
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                MISA investment licenses available across diverse sectors
                aligned with Vision 2030 objectives.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  sector: "Technology & Innovation",
                  image:
                    "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg",
                  activities: [
                    "Software Development",
                    "Fintech Services",
                    "E-commerce Platforms",
                    "AI & Robotics",
                    "Cybersecurity",
                  ],
                  investment: "SAR 500K - 10M+",
                  timeline: "20-25 days",
                },
                {
                  sector: "Manufacturing & Industrial",
                  image:
                    "https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg",
                  activities: [
                    "Light Manufacturing",
                    "Automotive Parts",
                    "Food Processing",
                    "Textiles",
                    "Electronics",
                  ],
                  investment: "SAR 2M - 50M+",
                  timeline: "25-35 days",
                },
                {
                  sector: "Healthcare & Medical",
                  image:
                    "https://images.pexels.com/photos/236380/pexels-photo-236380.jpeg",
                  activities: [
                    "Medical Facilities",
                    "Pharmaceuticals",
                    "Medical Devices",
                    "Telemedicine",
                    "Health Tech",
                  ],
                  investment: "SAR 1M - 20M+",
                  timeline: "30-40 days",
                },
                {
                  sector: "Logistics & Transportation",
                  image:
                    "https://images.pexels.com/photos/2226457/pexels-photo-2226457.jpeg",
                  activities: [
                    "Freight Services",
                    "Warehousing",
                    "Last-Mile Delivery",
                    "Cold Chain",
                    "Maritime Services",
                  ],
                  investment: "SAR 1M - 15M+",
                  timeline: "20-30 days",
                },
                {
                  sector: "Hospitality & Tourism",
                  image:
                    "https://images.pexels.com/photos/14749879/pexels-photo-14749879.jpeg",
                  activities: [
                    "Hotels & Resorts",
                    "Tourism Services",
                    "Event Management",
                    "Entertainment",
                    "Cultural Services",
                  ],
                  investment: "SAR 2M - 100M+",
                  timeline: "25-35 days",
                },
                {
                  sector: "Professional Services",
                  image:
                    "https://images.pexels.com/photos/7984742/pexels-photo-7984742.jpeg",
                  activities: [
                    "Consulting",
                    "Legal Services",
                    "Financial Services",
                    "Engineering",
                    "Architecture",
                  ],
                  investment: "SAR 500K - 5M+",
                  timeline: "15-25 days",
                },
              ].map((sector, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="relative h-48 overflow-hidden rounded-t-lg">
                    <img
                      src={sector.image}
                      alt={`${sector.sector} MISA investment opportunities`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                      <div className="p-4 text-white">
                        <h3 className="text-lg font-bold">{sector.sector}</h3>
                        <div className="flex gap-4 text-xs mt-1">
                          <span>Investment: {sector.investment}</span>
                          <span>•</span>
                          <span>Timeline: {sector.timeline}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-navy mb-3">
                      Eligible Activities:
                    </h4>
                    <ul className="space-y-2">
                      {sector.activities.map((activity, actIndex) => (
                        <li
                          key={actIndex}
                          className="flex items-center gap-2 text-sm"
                        >
                          <span className="w-1.5 h-1.5 bg-coral rounded-full"></span>
                          <span className="text-muted">{activity}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Success Stories */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                MISA Success Stories
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Real results from companies we've helped secure MISA investment
                licenses.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-gray-200 shadow-sm bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-coral to-coral-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold">TV</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-navy">TechVision Europe</h4>
                      <p className="text-sm text-muted">
                        Fintech Platform - Netherlands
                      </p>
                    </div>
                  </div>
                  <blockquote className="text-muted italic mb-4">
                    "SafaArban's MISA expertise was exceptional. They guided us
                    through every step, prepared all documents professionally,
                    and secured our license in just 22 days. Their former MISA
                    consultant was invaluable."
                  </blockquote>
                  <div className="grid grid-cols-2 gap-4 text-center text-sm">
                    <div>
                      <div className="font-bold text-coral">22 days</div>
                      <div className="text-muted">Processing Time</div>
                    </div>
                    <div>
                      <div className="font-bold text-coral">$2.5M</div>
                      <div className="text-muted">Investment</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-navy to-navy-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold">AM</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-navy">
                        AsiaManufacturing Ltd
                      </h4>
                      <p className="text-sm text-muted">
                        Automotive Parts - Singapore
                      </p>
                    </div>
                  </div>
                  <blockquote className="text-muted italic mb-4">
                    "Complex manufacturing licensing made simple. SafaArban's
                    sector expertise and government relationships ensured our
                    MISA license was approved without delays. Outstanding
                    service quality."
                  </blockquote>
                  <div className="grid grid-cols-2 gap-4 text-center text-sm">
                    <div>
                      <div className="font-bold text-coral">28 days</div>
                      <div className="text-muted">Processing Time</div>
                    </div>
                    <div>
                      <div className="font-bold text-coral">$8.2M</div>
                      <div className="text-muted">Investment</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
              Ready to Secure Your MISA Investment License?
            </h2>
            <p className="text-lg text-muted mb-8">
              Get expert guidance from former MISA consultants with 98% success
              rate. Start your Saudi investment journey with confidence.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-coral mb-2">98%</div>
                <div className="text-sm text-muted">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-coral mb-2">20-30</div>
                <div className="text-sm text-muted">Days Processing</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-coral mb-2">200+</div>
                <div className="text-sm text-muted">Licenses Secured</div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                asChild
                className="bg-navy text-white hover:bg-navy-600 shadow-lg"
              >
                <Link to="/contact">Get MISA License Quote</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
                className="border-gray-300 text-navy hover:bg-gray-50"
              >
                <a
                  href="https://wa.me/966536182180"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  WhatsApp Consultation
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
