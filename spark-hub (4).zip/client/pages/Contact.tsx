import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function Contact() {
  const pageTitle =
    "Contact SafaArban - Get Your Saudi Business Setup Quote Today";
  const pageDescription =
    "Contact SafaArban for expert Saudi business setup services. Get custom quotes for MISA licensing, Commercial Registration, and complete business formation solutions.";

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    entityType: "",
    sector: "",
    details: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    alert(
      "Thank you! Your request has been sent. We will reply with an itemized proposal and timeline.",
    );
    setFormData({
      name: "",
      email: "",
      phone: "",
      company: "",
      entityType: "",
      sector: "",
      details: "",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const contactMethods = [
    {
      title: "WhatsApp",
      description: "Instant messaging for quick questions",
      detail: "+966 536 182 180",
      action: "Chat Now",
      link: "https://wa.me/966536182180",
    },
    {
      title: "Email",
      description: "Detailed inquiries and document sharing",
      detail: "hello@safaarban.com",
      action: "Send Email",
      link: "mailto:hello@safaarban.com",
    },
    {
      title: "Phone",
      description: "Direct consultation scheduling",
      detail: "+966 536 182 180",
      action: "Call Now",
      link: "tel:+966536182180",
    },
  ];

  const faqs = [
    {
      question: "How long does the process take?",
      answer:
        "Timeline varies by entity type and sector. MISA licenses typically take 15-30 days, followed by CR registration. We'll provide specific timelines in your custom proposal.",
    },
    {
      question: "Do you provide fixed-price packages?",
      answer:
        "No, we provide custom quotes only. Every business setup has unique requirements based on sector, entity type, and compliance needs.",
    },
    {
      question: "What information do you need to start?",
      answer:
        "We need your business concept, intended sector, preferred entity type, timeline, and any specific requirements. The more details you provide, the more accurate our proposal.",
    },
    {
      question: "Do you handle ongoing compliance?",
      answer:
        "Yes, we offer comprehensive PRO services including license renewals, government correspondence, compliance monitoring, and regulatory updates.",
    },
  ];

  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: origin ? `${origin}/` : undefined },
        { "@type": "ListItem", position: 2, name: "Contact", item: origin ? `${origin}/contact` : undefined },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faqs.map((f) => ({
        "@type": "Question",
        name: f.question,
        acceptedAnswer: { "@type": "Answer", text: f.answer },
      })),
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={pageTitle}
        description={pageDescription}
        keywords={[
          "contact saudi business setup",
          "get quote misa",
          "contact safaarban",
          "saudi company formation quote",
        ]}
        type="website"
        jsonLd={jsonLd}
      />
      <Header />

      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-gray-50/60 to-white py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
              <div>
                <h1 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
                  Get Your Custom Saudi Business Quote
                </h1>
                <p className="text-xl text-muted mb-8">
                  Complete the form below and our team will respond with an
                  itemized scope, timeline, and transparent pricing for your
                  specific requirements.
                </p>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-coral-50 border border-dashed border-coral-200 rounded-full text-coral font-semibold">
                  <span className="w-2 h-2 bg-coral rounded-full"></span>
                  Free consultation & proposal
                </div>
              </div>
              <div className="relative rounded-xl overflow-hidden shadow-lg">
                <img
                  src="https://images.pexels.com/photos/7820383/pexels-photo-7820383.jpeg"
                  alt="Professional consultation and document signing at SafaArban office"
                  className="w-full h-64 lg:h-80 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-coral/80 to-transparent flex items-center">
                  <div className="p-6 text-white">
                    <h3 className="text-lg font-bold">Professional Service</h3>
                    <p className="text-sm opacity-90">
                      Expert guidance every step of the way
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form & Methods */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-3 gap-12">
              {/* Quote Request Form */}
              <div className="lg:col-span-2">
                <Card className="border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-2xl">
                      Request Custom Quote
                    </CardTitle>
                    <p className="text-muted">
                      Provide details about your business setup needs and we'll
                      create a tailored proposal with transparent pricing.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Full Name *</Label>
                          <Input
                            id="name"
                            type="text"
                            placeholder="Your name"
                            value={formData.name}
                            onChange={(e) =>
                              handleInputChange("name", e.target.value)
                            }
                            required
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email">Work Email *</Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="name@company.com"
                            value={formData.email}
                            onChange={(e) =>
                              handleInputChange("email", e.target.value)
                            }
                            required
                            className="mt-1"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Phone / WhatsApp</Label>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+966 5…"
                            value={formData.phone}
                            onChange={(e) =>
                              handleInputChange("phone", e.target.value)
                            }
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="company">Company / Country</Label>
                          <Input
                            id="company"
                            type="text"
                            placeholder="Parent company & country"
                            value={formData.company}
                            onChange={(e) =>
                              handleInputChange("company", e.target.value)
                            }
                            className="mt-1"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="entityType">Entity Type</Label>
                          <Select
                            value={formData.entityType}
                            onValueChange={(value) =>
                              handleInputChange("entityType", value)
                            }
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select entity type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="llc">
                                Limited Liability Company (LLC)
                              </SelectItem>
                              <SelectItem value="branch">
                                Branch of Foreign Company
                              </SelectItem>
                              <SelectItem value="jsc">
                                Joint Stock Company (JSC)
                              </SelectItem>
                              <SelectItem value="unsure">
                                Unsure - Need Guidance
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="sector">Business Sector</Label>
                          <Select
                            value={formData.sector}
                            onValueChange={(value) =>
                              handleInputChange("sector", value)
                            }
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select sector" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="manufacturing">
                                Manufacturing
                              </SelectItem>
                              <SelectItem value="logistics">
                                Logistics & Transportation
                              </SelectItem>
                              <SelectItem value="hospitality">
                                Hospitality & Tourism
                              </SelectItem>
                              <SelectItem value="technology">
                                Technology & Innovation
                              </SelectItem>
                              <SelectItem value="healthcare">
                                Healthcare & Pharmaceuticals
                              </SelectItem>
                              <SelectItem value="realestate">
                                Real Estate & Construction
                              </SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="details">Project Details *</Label>
                        <Textarea
                          id="details"
                          placeholder="Tell us about your business goals, timeline, specific requirements, and any challenges you're facing..."
                          value={formData.details}
                          onChange={(e) =>
                            handleInputChange("details", e.target.value)
                          }
                          required
                          className="mt-1 min-h-[120px]"
                        />
                      </div>

                      <div className="flex flex-col sm:flex-row gap-4">
                        <Button
                          type="submit"
                          size="lg"
                          className="bg-navy text-white hover:bg-navy-600 flex-1"
                        >
                          Send Request
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="lg"
                          asChild
                          className="border-gray-300 text-navy hover:bg-gray-50"
                        >
                          <a
                            href="https://wa.me/966536182180"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            Chat on WhatsApp
                          </a>
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </div>

              {/* Contact Methods & FAQ */}
              <div className="space-y-8">
                {/* Contact Methods */}
                <div>
                  <h3 className="text-xl font-bold text-navy mb-6">
                    Other Ways to Reach Us
                  </h3>
                  <div className="space-y-4">
                    {contactMethods.map((method, index) => (
                      <Card key={index} className="border-gray-200 shadow-sm">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-semibold text-navy">
                              {method.title}
                            </h4>
                            <Button
                              size="sm"
                              variant="outline"
                              asChild
                              className="text-xs"
                            >
                              <a
                                href={method.link}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                {method.action}
                              </a>
                            </Button>
                          </div>
                          <p className="text-sm text-muted mb-1">
                            {method.description}
                          </p>
                          <p className="text-sm font-medium text-coral">
                            {method.detail}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Quick FAQ */}
                <div>
                  <h3 className="text-xl font-bold text-navy mb-6">
                    Quick Answers
                  </h3>
                  <div className="space-y-4">
                    {faqs.map((faq, index) => (
                      <Card key={index} className="border-gray-200 shadow-sm">
                        <CardContent className="p-4">
                          <h4 className="font-semibold text-navy mb-2 text-sm">
                            {faq.question}
                          </h4>
                          <p className="text-xs text-muted">{faq.answer}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Office Information */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Our Office
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Located in Riyadh, the business capital of Saudi Arabia, for
                direct access to government agencies and regulatory bodies.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="border-gray-200 shadow-sm bg-white">
                <CardHeader>
                  <CardTitle className="text-lg">Address</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted">
                    Business District
                    <br />
                    Riyadh, Kingdom of Saudi Arabia
                    <br />
                    <span className="text-xs">
                      Exact address provided upon engagement
                    </span>
                  </p>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm bg-white">
                <CardHeader>
                  <CardTitle className="text-lg">Business Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-muted space-y-1">
                    <p>Sunday - Thursday: 8:00 AM - 6:00 PM</p>
                    <p>Friday - Saturday: Closed</p>
                    <p className="text-xs mt-2">
                      WhatsApp available 24/7 for urgent matters
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm bg-white">
                <CardHeader>
                  <CardTitle className="text-lg">Languages</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-muted space-y-1">
                    <p>• English (Primary)</p>
                    <p>• Arabic (Official documents)</p>
                    <p>• Bengali (On request)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Response Time */}
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <div className="bg-gradient-to-r from-navy to-navy-600 text-white rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-4">
                Fast Response Guarantee
              </h3>
              <p className="text-lg opacity-90 mb-6">
                We respond to all quote requests within 24 hours with an initial
                assessment and next steps. Complex proposals are delivered
                within 48-72 hours.
              </p>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    24hr
                  </div>
                  <div className="text-sm opacity-90">Initial Response</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    48-72hr
                  </div>
                  <div className="text-sm opacity-90">Detailed Proposal</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    15min
                  </div>
                  <div className="text-sm opacity-90">WhatsApp Response</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
