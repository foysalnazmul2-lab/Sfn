import { useEffect, useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import SEO from "@/components/SEO";
import { getSupabase } from "@/lib/supabase";
import { authenticateDemoAccount, seedEmployeeDemoAccount } from "@/lib/demo-auth";

export default function AdminAuth() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation() as any;

  const supabase = getSupabase();
  const notConfigured = !supabase;

  useEffect(() => {
    if (notConfigured) {
      seedEmployeeDemoAccount();
    }
  }, [notConfigured]);

  const pageTitle = "Employee Login | SafaArban";
  const pageDescription = "Login to SafaArban operations portal.";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email || !password) {
      setError("Enter email and password.");
      return;
    }
    setLoading(true);
    try {
      if (notConfigured) {
        if (!email.trim().toLowerCase().endsWith("@safaarban.com")) {
          throw new Error("Use a @safaarban.com email for employee access.");
        }
        const account = await authenticateDemoAccount(email, password);
        if (account.role !== "employee") {
          throw new Error("This account does not have employee permissions.");
        }
        localStorage.setItem("demo_user", JSON.stringify({ email: account.email, role: account.role }));
        window.dispatchEvent(new Event("demo-auth-changed"));
      } else {
        const { error } = await supabase!.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      const to = location.state?.from?.pathname || "/admin";
      navigate(to, { replace: true });
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO title={pageTitle} description={pageDescription} />
      <Header />
      <main className="py-16 lg:py-24">
        <div className="max-w-md mx-auto px-4 sm:px-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Employee Login</CardTitle>
              <p className="text-sm text-muted">Use your @safaarban.com email</p>
            </CardHeader>
            <CardContent>
              {notConfigured && (
                <div className="mb-4 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded p-3 space-y-1">
                  <p>Supabase not connected. Demo accounts are stored locally.</p>
                  <p className="font-medium">Default demo employee: team@safaarban.com / safaarban123</p>
                </div>
              )}
              {error && (
                <div className="mb-4 text-xs text-red-700 bg-red-50 border border-red-200 rounded p-3">{error}</div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="mt-1" />
                </div>
                <Button type="submit" disabled={loading} className="w-full bg-navy text-white hover:bg-navy-600">
                  {loading ? "Please wait…" : "Login"}
                </Button>
              </form>
              <div className="text-center text-xs text-muted mt-4">
                <Link to="/">← Back to Home</Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
