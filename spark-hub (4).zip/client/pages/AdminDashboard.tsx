import { useEffect, useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import SEO from "@/components/SEO";
import { useAuth } from "@/context/AuthContext";
import {
  listAllRequests,
  ServiceRequest,
  ServiceRequestStatus,
  updateServiceRequestStatus,
} from "@/lib/service-requests";
import { useToast } from "@/hooks/use-toast";
import { getSupabase } from "@/lib/supabase";

const STATUS_OPTIONS: ServiceRequestStatus[] = ["New", "In Review", "In Progress", "Completed", "Rejected"];

export default function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const supabase = getSupabase();

  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    listAllRequests()
      .then((data) => {
        if (!active) return;
        setRequests(data);
      })
      .catch((err: unknown) => {
        if (!active) return;
        const message = err instanceof Error ? err.message : "Unable to load requests.";
        setError(message);
      })
      .finally(() => {
        if (!active) return;
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  async function changeStatus(request: ServiceRequest, status: ServiceRequestStatus) {
    if (request.status === status) return;
    setUpdatingId(request.id);
    try {
      const updated = await updateServiceRequestStatus({ id: request.id, status, email: request.email });
      setRequests((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
      toast({ title: "Status updated", description: `${request.service} → ${status}` });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to update status.";
      toast({ title: "Update failed", description: message, variant: "destructive" });
    } finally {
      setUpdatingId(null);
    }
  }

  async function signOut() {
    if (supabase) {
      await supabase.auth.signOut();
    } else {
      localStorage.removeItem("demo_user");
      window.dispatchEvent(new Event("demo-auth-changed"));
    }
    window.location.href = "/";
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-white">
        <SEO title="Employee Ops Portal | SafaArban" description="Manage customer requests and operations." />
        <Header />
        <main className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <p className="text-sm text-muted">Loading dashboard…</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO title="Employee Ops Portal | SafaArban" description="Manage customer requests and operations." />
      <Header />
      <main className="py-16 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-navy">Operations Dashboard</h1>
              <p className="text-sm text-muted">Track service requests and update their progress.</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted">{user?.email}</span>
              <Button onClick={signOut} variant="outline" size="sm" className="text-xs">
                Sign out
              </Button>
            </div>
          </div>
          <Card className="border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle>Service Requests</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <p className="text-sm text-muted">Loading requests…</p>
              ) : error ? (
                <div className="text-xs text-red-700 bg-red-50 border border-red-200 rounded p-3">{error}</div>
              ) : requests.length === 0 ? (
                <p className="text-sm text-muted">No requests yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-gray-600">
                        <th className="py-2 pr-4">Customer</th>
                        <th className="py-2 pr-4">Service</th>
                        <th className="py-2 pr-4">Description</th>
                        <th className="py-2 pr-4">Created</th>
                        <th className="py-2 pr-4">Status</th>
                        <th className="py-2 pr-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {requests.map((r) => (
                        <tr key={r.id} className="border-t border-gray-100">
                          <td className="py-2 pr-4">{r.email}</td>
                          <td className="py-2 pr-4">{r.service}</td>
                          <td className="py-2 pr-4 max-w-md truncate" title={r.description}>
                            {r.description}
                          </td>
                          <td className="py-2 pr-4">{new Date(r.createdAt).toLocaleString()}</td>
                          <td className="py-2 pr-4">{r.status}</td>
                          <td className="py-2 pr-4">
                            <div className="flex flex-wrap gap-2">
                              {STATUS_OPTIONS.map((status) => (
                                <Button
                                  key={status}
                                  size="sm"
                                  variant={status === r.status ? "default" : "outline"}
                                  className="text-xs"
                                  disabled={updatingId === r.id}
                                  onClick={() => changeStatus(r, status)}
                                >
                                  {status}
                                </Button>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
