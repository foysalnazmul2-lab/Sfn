import { useEffect, useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import SEO from "@/components/SEO";
import { useAuth } from "@/context/AuthContext";
import { getSupabase } from "@/lib/supabase";
import {
  createServiceRequest,
  listCustomerRequests,
  ServiceRequest,
} from "@/lib/service-requests";
import { useToast } from "@/hooks/use-toast";

const SERVICE_OPTIONS = [
  "MISA Investment License",
  "Commercial Registration (CR)",
  "ZATCA / GOSI / Qiwa",
  "Municipality Permits",
  "Manufacturing / Industrial License",
  "Technology / Fintech Permits",
  "Healthcare Licensing",
  "Logistics & Transportation",
  "Real Estate & Construction",
  "Premium Residency (SP1)",
  "Corporate Banking Setup",
  "Ongoing PRO Services",
];

export default function Portal() {
  const { user, loading: authLoading } = useAuth();
  const supabase = getSupabase();
  const { toast } = useToast();

  const [service, setService] = useState("");
  const [description, setDescription] = useState("");
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loadingRequests, setLoadingRequests] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    const email = user.email ?? "";
    if (!supabase && !email) {
      setLoadError("Your account is missing an email address. Please log out and log back in.");
      setLoadingRequests(false);
      return;
    }
    let active = true;
    setLoadingRequests(true);
    setLoadError(null);
    listCustomerRequests({ userId: user.id, email: email || user.id })
      .then((data) => {
        if (!active) return;
        setRequests(data);
      })
      .catch((err: unknown) => {
        if (!active) return;
        const message = err instanceof Error ? err.message : "Unable to load requests.";
        setLoadError(message);
      })
      .finally(() => {
        if (!active) return;
        setLoadingRequests(false);
      });
    return () => {
      active = false;
    };
  }, [user?.id, user?.email, supabase]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user?.id) return;
    const email = user.email ?? "";
    if (!service) {
      setSubmitError("Select a service to continue.");
      return;
    }
    if (!description.trim()) {
      setSubmitError("Provide details about your request.");
      return;
    }
    if (!supabase && !email) {
      setSubmitError("Your account is missing an email address. Please log out and log back in.");
      return;
    }
    setSubmitError(null);
    setSubmitting(true);
    try {
      const created = await createServiceRequest({
        userId: user.id,
        email: email || user.id,
        service,
        description: description.trim(),
      });
      setRequests((prev) => [created, ...prev.filter((r) => r.id !== created.id)]);
      setService("");
      setDescription("");
      toast({
        title: "Request submitted",
        description: "Our team will reach out shortly.",
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to submit request.";
      setSubmitError(message);
    } finally {
      setSubmitting(false);
    }
  }

  async function signOut() {
    if (supabase) {
      await supabase.auth.signOut();
    } else {
      localStorage.removeItem("demo_user");
      window.dispatchEvent(new Event("demo-auth-changed"));
    }
    window.location.href = "/";
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-white">
        <SEO title="Customer Portal | SafaArban" description="Access your requests, documents and messages." />
        <Header />
        <main className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <p className="text-sm text-muted">Loading your portal…</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO title="Customer Portal | SafaArban" description="Access your requests, documents and messages." />
      <Header />
      <main className="py-16 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold text-navy">Customer Portal</h1>
            <Button onClick={signOut} className="bg-navy text-white hover:bg-navy-600">
              Sign out
            </Button>
          </div>
          <p className="text-muted mb-8">Welcome {user?.email}. Create and track your service requests.</p>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="border-gray-200 shadow-sm md:col-span-2">
              <CardHeader>
                <CardTitle>Create Service Request</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label htmlFor="service" className="text-sm font-medium text-navy">
                      Service
                    </label>
                    <div className="mt-1">
                      <select
                        id="service"
                        value={service}
                        onChange={(e) => setService(e.target.value)}
                        className="w-full border rounded-md px-3 py-2"
                        disabled={submitting}
                        required
                      >
                        <option value="">Select a service…</option>
                        {SERVICE_OPTIONS.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="md:col-span-2">
                    <label htmlFor="desc" className="text-sm font-medium text-navy">
                      Details
                    </label>
                    <Textarea
                      id="desc"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="mt-1 min-h-[120px]"
                      placeholder="Describe your needs, timeline, and any specifics"
                      disabled={submitting}
                      required
                    />
                  </div>
                  {submitError && (
                    <div className="md:col-span-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded p-3">
                      {submitError}
                    </div>
                  )}
                  <div className="md:col-span-2">
                    <Button type="submit" disabled={submitting} className="bg-navy text-white hover:bg-navy-600">
                      {submitting ? "Submitting…" : "Submit Request"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
            <Card className="border-gray-200 shadow-sm">
              <CardHeader>
                <CardTitle>Quick Links</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <a className="text-coral" href="https://wa.me/966536182180" target="_blank" rel="noopener noreferrer">
                    WhatsApp Support →
                  </a>
                  <a className="text-navy" href="mailto:hello@safaarban.com">
                    Email Support →
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle>My Requests</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingRequests ? (
                <p className="text-sm text-muted">Loading your requests…</p>
              ) : loadError ? (
                <div className="text-xs text-red-700 bg-red-50 border border-red-200 rounded p-3">{loadError}</div>
              ) : requests.length === 0 ? (
                <p className="text-sm text-muted">No requests yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-gray-600">
                        <th className="py-2 pr-4">Service</th>
                        <th className="py-2 pr-4">Created</th>
                        <th className="py-2 pr-4">Status</th>
                        <th className="py-2 pr-4">Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {requests.map((r) => (
                        <tr key={r.id} className="border-t border-gray-100">
                          <td className="py-2 pr-4">{r.service}</td>
                          <td className="py-2 pr-4">{new Date(r.createdAt).toLocaleString()}</td>
                          <td className="py-2 pr-4">{r.status}</td>
                          <td className="py-2 pr-4 max-w-lg truncate" title={r.description}>
                            {r.description}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
