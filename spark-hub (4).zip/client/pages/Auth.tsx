import { useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import SEO from "@/components/SEO";
import { getSupabase } from "@/lib/supabase";
import { authenticateDemoAccount, createDemoAccount } from "@/lib/demo-auth";

export default function Auth() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation() as any;

  const supabase = getSupabase();
  const notConfigured = !supabase;

  const pageTitle = mode === "login" ? "Login to SafaArban Portal" : "Create your SafaArban Account";
  const pageDescription = mode === "login" ? "Access your customer portal to track requests and documents." : "Sign up with your email to access the SafaArban customer portal.";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email || !password) {
      setError("Please enter email and password.");
      return;
    }
    setLoading(true);
    try {
      const normalizedEmail = email.trim().toLowerCase();
      const derivedRole: "customer" | "employee" = normalizedEmail.endsWith("@safaarban.com") ? "employee" : "customer";
      if (notConfigured) {
        if (mode === "login") {
          const account = await authenticateDemoAccount(normalizedEmail, password);
          localStorage.setItem("demo_user", JSON.stringify({ email: account.email, role: account.role }));
        } else {
          const account = await createDemoAccount(normalizedEmail, password, derivedRole);
          localStorage.setItem("demo_user", JSON.stringify({ email: account.email, role: account.role }));
        }
        window.dispatchEvent(new Event("demo-auth-changed"));
      } else if (mode === "login") {
        const { error } = await supabase!.auth.signInWithPassword({ email: normalizedEmail, password });
        if (error) throw error;
      } else {
        const { data, error } = await supabase!.auth.signUp({ email: normalizedEmail, password, options: { data: { role: derivedRole } } });
        if (error) throw error;
        if (!data.session) {
          const { error: loginError } = await supabase!.auth.signInWithPassword({ email: normalizedEmail, password });
          if (loginError) throw loginError;
        }
      }
      const to = location.state?.from?.pathname || "/portal";
      navigate(to, { replace: true });
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO title={pageTitle} description={pageDescription} type="website" keywords={["login","signup","customer portal","safaarban"]} />
      <Header />
      <main className="py-16 lg:py-24">
        <div className="max-w-md mx-auto px-4 sm:px-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">{mode === "login" ? "Login" : "Create Account"}</CardTitle>
              <p className="text-sm text-muted">
                {mode === "login" ? "Enter your email and password to access your portal." : "Sign up with your email and password."}
              </p>
            </CardHeader>
            <CardContent>
              {notConfigured && (
                <div className="mb-4 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded p-3">
                  Supabase not connected. Accounts will be stored locally for demo use. To enable production login, click Open MCP popover, connect Supabase, and set VITE_SUPABASE_URL plus VITE_SUPABASE_ANON_KEY.
                </div>
              )}
              {error && (
                <div className="mb-4 text-xs text-red-700 bg-red-50 border border-red-200 rounded p-3">{error}</div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="mt-1" />
                </div>
                <Button type="submit" disabled={loading} className="w-full bg-navy text-white hover:bg-navy-600">
                  {loading ? "Please wait…" : mode === "login" ? "Login" : "Sign Up"}
                </Button>
              </form>
              <div className="text-center text-sm mt-4">
                {mode === "login" ? (
                  <span>
                    No account? <button className="text-coral font-semibold" onClick={() => setMode("signup")}>Sign up</button>
                  </span>
                ) : (
                  <span>
                    Have an account? <button className="text-coral font-semibold" onClick={() => setMode("login")}>Login</button>
                  </span>
                )}
              </div>
              <div className="text-center text-xs text-muted mt-2">
                <Link to="/">← Back to Home</Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
