import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main>
        <section className="py-24 lg:py-32">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <div className="mb-8">
              <div className="text-6xl lg:text-8xl font-bold text-coral mb-4">
                404
              </div>
              <h1 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Page Not Found
              </h1>
              <p className="text-lg text-muted mb-8 max-w-2xl mx-auto">
                The page you're looking for doesn't exist. It might have been
                moved, deleted, or you entered the wrong URL.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                asChild
                className="bg-navy text-white hover:bg-navy-600 shadow-lg"
              >
                <Link to="/">Go to Homepage</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
                className="border-gray-300 text-navy hover:bg-gray-50"
              >
                <Link to="/contact">Contact Support</Link>
              </Button>
            </div>

            {/* Quick Links */}
            <div className="border-t border-gray-200 pt-8">
              <h2 className="text-xl font-semibold text-navy mb-6">
                Popular Pages
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-3xl mx-auto">
                <Link
                  to="/services"
                  className="p-4 border border-gray-200 rounded-lg hover:border-coral hover:bg-coral-50 transition-colors text-center"
                >
                  <h3 className="font-semibold text-navy mb-1">Services</h3>
                  <p className="text-sm text-muted">
                    Our complete service offerings
                  </p>
                </Link>
                <Link
                  to="/about"
                  className="p-4 border border-gray-200 rounded-lg hover:border-coral hover:bg-coral-50 transition-colors text-center"
                >
                  <h3 className="font-semibold text-navy mb-1">About</h3>
                  <p className="text-sm text-muted">Learn about SafaArban</p>
                </Link>
                <Link
                  to="/blog"
                  className="p-4 border border-gray-200 rounded-lg hover:border-coral hover:bg-coral-50 transition-colors text-center"
                >
                  <h3 className="font-semibold text-navy mb-1">Blog</h3>
                  <p className="text-sm text-muted">
                    Latest insights and updates
                  </p>
                </Link>
                <Link
                  to="/contact"
                  className="p-4 border border-gray-200 rounded-lg hover:border-coral hover:bg-coral-50 transition-colors text-center"
                >
                  <h3 className="font-semibold text-navy mb-1">Contact</h3>
                  <p className="text-sm text-muted">Get in touch with us</p>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
