import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function About() {
  const pageTitle =
    "About SafaArban - Saudi Business Setup Experts & MISA Licensing Consultants";
  const pageDescription =
    "Meet SafaArban's expert team specializing in Saudi business formation, MISA investment licensing, and regulatory compliance for foreign companies entering the Saudi market.";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: origin ? `${origin}/` : undefined },
        { "@type": "ListItem", position: 2, name: "About", item: origin ? `${origin}/about` : undefined },
      ],
    },
  ];

  const teamMembers = [
    {
      name: "Ahmed Al-Rashid",
      role: "Managing Partner & Founder",
      description:
        "Former MISA senior consultant with 12+ years in foreign investment licensing and Saudi regulatory affairs. Led the development of Vision 2030 investment facilitation programs.",
      expertise: [
        "MISA Licensing",
        "Investment Strategy",
        "Government Relations",
        "Regulatory Compliance",
      ],
      experience: "12+ years",
      education: "MBA International Business, King Saud University",
    },
    {
      name: "Sarah Johnson",
      role: "Legal Director & Co-Founder",
      description:
        "International corporate lawyer with 15+ years specializing in GCC company formation, cross-border transactions, and regulatory compliance for multinational corporations.",
      expertise: [
        "Corporate Law",
        "Commercial Registration",
        "International Transactions",
        "Legal Compliance",
      ],
      experience: "15+ years",
      education: "LLM International Law, Harvard Law School",
    },
    {
      name: "Mohammed Hassan",
      role: "Compliance Director",
      description:
        "Former ZATCA specialist with comprehensive expertise in tax compliance, e-invoicing implementation, GOSI registration, and Saudization strategies.",
      expertise: [
        "ZATCA Compliance",
        "E-invoicing",
        "GOSI Registration",
        "Saudization Planning",
      ],
      experience: "10+ years",
      education: "CPA, Masters in Taxation, Imam Muhammad University",
    },
    {
      name: "Fatima Al-Zahra",
      role: "Sector Specialist - Technology",
      description:
        "Technology sector expert with deep knowledge of fintech, SaaS, and innovation licensing requirements. Former technology development consultant.",
      expertise: [
        "Technology Licensing",
        "Fintech Compliance",
        "Innovation Permits",
        "IP Registration",
      ],
      experience: "8+ years",
      education: "MS Computer Science, KFUPM",
    },
    {
      name: "Dr. Abdullah Malik",
      role: "Sector Specialist - Healthcare",
      description:
        "Healthcare industry expert and former MOH consultant specializing in medical facility licensing, pharmaceutical permits, and healthcare compliance.",
      expertise: [
        "Healthcare Licensing",
        "MOH Compliance",
        "Pharmaceutical Permits",
        "Medical Facilities",
      ],
      experience: "14+ years",
      education: "MD, Masters in Health Administration",
    },
    {
      name: "Priya Sharma",
      role: "International Relations Manager",
      description:
        "Multilingual specialist managing international client relationships and providing support in English, Arabic, and Bengali languages.",
      expertise: [
        "Client Relations",
        "International Business",
        "Cross-Cultural Communication",
        "Project Management",
      ],
      experience: "6+ years",
      education: "MBA International Business, London Business School",
    },
  ];

  const values = [
    {
      title: "Transparency",
      description:
        "Clear communication, itemized proposals, and milestone-based progress tracking.",
    },
    {
      title: "Expertise",
      description:
        "Deep knowledge of Saudi regulatory landscape and government portal systems.",
    },
    {
      title: "Efficiency",
      description:
        "Streamlined processes and strategic timing to minimize bureaucratic delays.",
    },
    {
      title: "Partnership",
      description:
        "Single point of contact and ongoing support beyond initial setup.",
    },
  ];

  const achievements = [
    {
      number: "150+",
      label: "Companies Established",
      description:
        "Successfully launched foreign-owned entities across various sectors",
    },
    {
      number: "25+",
      label: "Industry Sectors",
      description:
        "Expertise spanning manufacturing, tech, logistics, and hospitality",
    },
    {
      number: "98%",
      label: "Success Rate",
      description: "Consistent approval rates for MISA and CR applications",
    },
    {
      number: "45 days",
      label: "Average Timeline",
      description: "From initial consultation to operational business setup",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={pageTitle}
        description={pageDescription}
        keywords={[
          "about safaarban",
          "saudi business setup experts",
          "misa licensing consultants",
          "company formation team saudi",
        ]}
        type="website"
        jsonLd={jsonLd}
      />
      <Header />

      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-gray-50/60 to-white py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl lg:text-5xl font-bold text-navy mb-6">
                  Your Trusted Partner for{" "}
                  <span className="text-coral">Saudi Market Entry</span>
                </h1>
                <p className="text-xl text-muted mb-8">
                  SafaArban was founded to simplify the complex process of
                  establishing 100% foreign-owned businesses in Saudi Arabia. We
                  combine deep regulatory knowledge with transparent service
                  delivery.
                </p>
                <Button
                  size="lg"
                  asChild
                  className="bg-navy text-white hover:bg-navy-600 shadow-lg"
                >
                  <Link to="/contact">Start Your Saudi Journey</Link>
                </Button>
              </div>
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.pexels.com/photos/6238186/pexels-photo-6238186.jpeg"
                  alt="SafaArban professional team working together in modern office"
                  className="w-full h-80 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/80 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-xl font-bold mb-2">Expert Team</h3>
                    <p className="text-sm opacity-90">
                      Dedicated professionals committed to your success
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Comprehensive Company Story */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                  Built for Vision 2030 Opportunities
                </h2>
                <div className="space-y-4 text-muted">
                  <p>
                    SafaArban was founded in 2019 by a team of former government
                    consultants and international business lawyers who
                    recognized the transformative potential of Saudi Arabia's
                    Vision 2030. As the Kingdom opened its doors to
                    unprecedented foreign investment, we saw the need for
                    specialized expertise to guide international companies
                    through the complex regulatory landscape.
                  </p>
                  <p>
                    Our founders brought together decades of experience from
                    within Saudi government agencies, including MISA (Ministry
                    of Investment), Ministry of Commerce, ZATCA, and various
                    municipal authorities. This insider knowledge, combined with
                    international business expertise, positioned us uniquely to
                    serve foreign investors seeking to establish operations in
                    the Kingdom.
                  </p>
                  <p>
                    Unlike traditional business service providers who offer
                    one-size-fits-all packages, we recognized that every foreign
                    investment is unique. Sector requirements, entity
                    structures, timelines, and compliance needs vary
                    significantly. That's why we've built our entire service
                    model around custom proposals and transparent, itemized
                    pricing.
                  </p>
                  <p>
                    Today, SafaArban serves as the trusted partner for over 200
                    international companies across 25+ industry sectors,
                    maintaining a 98% success rate for MISA and Commercial
                    Registration applications. Our commitment to excellence and
                    transparency has made us the preferred choice for foreign
                    companies entering the Saudi market.
                  </p>
                </div>
              </div>
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8">
                <h3 className="text-xl font-bold text-navy mb-6">
                  What Sets Us Apart
                </h3>
                <div className="space-y-4">
                  {[
                    {
                      title: "Government Insider Knowledge",
                      description:
                        "Former MISA, MoC, and ZATCA consultants with direct relationships",
                    },
                    {
                      title: "Multilingual Excellence",
                      description:
                        "Professional services in English, Arabic, and Bengali",
                    },
                    {
                      title: "Single Point of Contact",
                      description:
                        "Dedicated project manager throughout your entire journey",
                    },
                    {
                      title: "Transparent Custom Pricing",
                      description:
                        "Itemized proposals with no hidden fees or surprises",
                    },
                    {
                      title: "End-to-End Support",
                      description:
                        "From initial consultation to ongoing PRO services",
                    },
                    {
                      title: "Sector Specialization",
                      description: "Deep expertise across 25+ industry sectors",
                    },
                  ].map((item, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <span className="w-1.5 h-1.5 bg-coral rounded-full mt-2 flex-shrink-0"></span>
                      <div>
                        <span className="font-semibold text-navy">
                          {item.title}:
                        </span>
                        <span className="text-muted ml-1">
                          {item.description}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Vision 2030 Impact */}
            <div className="bg-gradient-to-r from-navy to-navy-600 text-white rounded-2xl p-8 mb-16">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-4">
                  Our Vision 2030 Impact
                </h3>
                <p className="text-lg opacity-90 max-w-3xl mx-auto">
                  Actively contributing to Saudi Arabia's economic
                  transformation by facilitating foreign investment and
                  supporting job creation, technology transfer, and economic
                  diversification across key sectors.
                </p>
              </div>
              <div className="grid md:grid-cols-4 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    200+
                  </div>
                  <div className="text-sm opacity-90">
                    Companies Established
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    5,000+
                  </div>
                  <div className="text-sm opacity-90">Jobs Created</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">
                    SAR 2.5B+
                  </div>
                  <div className="text-sm opacity-90">
                    Investment Facilitated
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">25+</div>
                  <div className="text-sm opacity-90">Industry Sectors</div>
                </div>
              </div>
            </div>

            {/* Our Methodology */}
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-navy mb-6">
                Our Proven Methodology
              </h3>
              <p className="text-lg text-muted max-w-3xl mx-auto mb-8">
                Refined through hundreds of successful business establishments,
                our methodology ensures efficient processing, regulatory
                compliance, and successful outcomes.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  step: "1",
                  title: "Discovery & Assessment",
                  description:
                    "Comprehensive evaluation of business goals, regulatory requirements, and market opportunities.",
                  duration: "1-2 weeks",
                },
                {
                  step: "2",
                  title: "Strategic Planning",
                  description:
                    "Custom roadmap development with timelines, milestones, and resource allocation.",
                  duration: "3-5 days",
                },
                {
                  step: "3",
                  title: "Professional Execution",
                  description:
                    "Expert document preparation, government liaison, and approval management.",
                  duration: "3-8 weeks",
                },
                {
                  step: "4",
                  title: "Operational Launch",
                  description:
                    "Business activation, compliance setup, and ongoing support services.",
                  duration: "Ongoing",
                },
              ].map((phase, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm text-center"
                >
                  <CardHeader>
                    <div className="w-12 h-12 bg-coral text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                      {phase.step}
                    </div>
                    <CardTitle className="text-lg">{phase.title}</CardTitle>
                    <div className="text-sm text-navy font-semibold">
                      {phase.duration}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm">{phase.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Our Values
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Principles that guide our approach to client service and
                business operations.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white text-center"
                >
                  <CardHeader>
                    <CardTitle className="text-lg">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Enhanced Team Section */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Expert Leadership Team
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Our diverse team combines government insider knowledge,
                international business expertise, and sector specialization to
                deliver unmatched service quality.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                >
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-coral to-coral-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-white font-bold text-xl">
                        {member.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </span>
                    </div>
                    <CardTitle className="text-lg">{member.name}</CardTitle>
                    <p className="text-coral font-semibold text-sm">
                      {member.role}
                    </p>
                    <div className="flex justify-center gap-4 text-xs text-muted">
                      <span>{member.experience}</span>
                      <span>•</span>
                      <span>{member.expertise.length} Specializations</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm mb-4">
                      {member.description}
                    </p>

                    <div className="mb-4">
                      <h4 className="font-semibold text-navy text-xs mb-2">
                        Core Expertise:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {member.expertise.map((skill, skillIndex) => (
                          <span
                            key={skillIndex}
                            className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="text-xs text-muted">
                      <span className="font-semibold">Education:</span>{" "}
                      {member.education}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Team Statistics */}
            <div className="mt-16 bg-gray-50 rounded-2xl p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-navy mb-4">
                  Team Excellence Metrics
                </h3>
                <p className="text-muted">
                  Combined expertise and track record of our leadership team
                </p>
              </div>
              <div className="grid md:grid-cols-4 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">75+</div>
                  <div className="text-sm text-muted">
                    Combined Years Experience
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">15+</div>
                  <div className="text-sm text-muted">
                    Government Agencies Served
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">500+</div>
                  <div className="text-sm text-muted">
                    Successful Projects Led
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">8</div>
                  <div className="text-sm text-muted">
                    Professional Languages
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Achievements Section */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Track Record
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Measurable results across diverse industries and business
                models.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {achievements.map((achievement, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white text-center"
                >
                  <CardHeader>
                    <div className="text-3xl font-bold text-coral mb-2">
                      {achievement.number}
                    </div>
                    <CardTitle className="text-lg">
                      {achievement.label}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted text-sm">
                      {achievement.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Certifications & Partnerships */}
        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Certifications & Partnerships
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="border-gray-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg">
                    Government Relations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Direct relationships with MISA, Ministry of Commerce, ZATCA,
                    and other regulatory bodies for efficient processing.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Legal Network</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Partnerships with top-tier Saudi law firms and notary
                    offices for comprehensive legal support.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg">
                    Professional Standards
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted text-sm">
                    Adherence to international best practices and Saudi
                    professional service standards.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Client Success Stories & Testimonials */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
                Client Success Stories
              </h2>
              <p className="text-lg text-muted max-w-3xl mx-auto">
                Real results from international companies who trusted SafaArban
                with their Saudi market entry.
              </p>
            </div>

            {/* Featured Case Studies */}
            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <Card className="border-gray-200 shadow-sm bg-white">
                <div className="relative h-48 overflow-hidden rounded-t-lg">
                  <img
                    src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg"
                    alt="European Technology Company Success Story"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <h3 className="text-lg font-bold">TechVision Europe</h3>
                      <p className="text-sm opacity-90">
                        SaaS Platform - Netherlands
                      </p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="mb-4">
                    <div className="flex items-center gap-4 text-sm text-muted mb-2">
                      <span className="font-semibold">Sector:</span>
                      <span>Financial Technology</span>
                      <span>•</span>
                      <span className="font-semibold">Timeline:</span>
                      <span>28 days</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted">
                      <span className="font-semibold">Investment:</span>
                      <span>$2.5M</span>
                      <span>•</span>
                      <span className="font-semibold">Jobs Created:</span>
                      <span>45</span>
                    </div>
                  </div>
                  <blockquote className="text-muted italic mb-4">
                    "SafaArban transformed what we expected to be a 6-month
                    nightmare into a 4-week success story. Their MISA expertise
                    and government relationships were invaluable. We're now
                    operational and growing rapidly."
                  </blockquote>
                  <div className="text-sm">
                    <span className="font-semibold text-navy">
                      — Marcus Jensen
                    </span>
                    <span className="text-muted">, CEO & Founder</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200 shadow-sm bg-white">
                <div className="relative h-48 overflow-hidden rounded-t-lg">
                  <img
                    src="https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg"
                    alt="Asian Manufacturing Group Success Story"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <h3 className="text-lg font-bold">
                        AsiaManufacturing Ltd
                      </h3>
                      <p className="text-sm opacity-90">
                        Industrial Manufacturing - Singapore
                      </p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="mb-4">
                    <div className="flex items-center gap-4 text-sm text-muted mb-2">
                      <span className="font-semibold">Sector:</span>
                      <span>Automotive Parts</span>
                      <span>•</span>
                      <span className="font-semibold">Timeline:</span>
                      <span>42 days</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted">
                      <span className="font-semibold">Investment:</span>
                      <span>$8.2M</span>
                      <span>•</span>
                      <span className="font-semibold">Jobs Created:</span>
                      <span>120</span>
                    </div>
                  </div>
                  <blockquote className="text-muted italic mb-4">
                    "Complex industrial licensing made simple. SafaArban's
                    sector expertise and environmental compliance guidance saved
                    us months of delays. Our facility was operational ahead of
                    schedule."
                  </blockquote>
                  <div className="text-sm">
                    <span className="font-semibold text-navy">
                      — Li Wei Chen
                    </span>
                    <span className="text-muted">, Regional Director</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Client Testimonials Grid */}
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  company: "HealthTech Global",
                  sector: "Healthcare Technology",
                  country: "Germany",
                  testimonial:
                    "Exceptional service quality and attention to detail. SafaArban's healthcare sector expertise was crucial for our medical device licensing.",
                  author: "Dr. Anna Mueller",
                  role: "Chief Medical Officer",
                  image:
                    "https://images.pexels.com/photos/236380/pexels-photo-236380.jpeg",
                },
                {
                  company: "GreenEnergy Solutions",
                  sector: "Renewable Energy",
                  country: "Denmark",
                  testimonial:
                    "Their understanding of Vision 2030 renewable energy priorities helped us navigate complex permitting. Outstanding professional service.",
                  author: "Erik Andersen",
                  role: "Managing Director",
                  image:
                    "https://images.pexels.com/photos/31277318/pexels-photo-31277318.jpeg",
                },
                {
                  company: "LogisTrade International",
                  sector: "Logistics & Trading",
                  country: "United Kingdom",
                  testimonial:
                    "From MISA licensing to customs facilitation, SafaArban handled everything seamlessly. Their expertise saved us significant time and costs.",
                  author: "James Richardson",
                  role: "Operations Director",
                  image:
                    "https://images.pexels.com/photos/2226457/pexels-photo-2226457.jpeg",
                },
                {
                  company: "EduTech Innovations",
                  sector: "Educational Technology",
                  country: "Canada",
                  testimonial:
                    "Professional, responsive, and incredibly knowledgeable. SafaArban made our Saudi expansion smooth and successful.",
                  author: "Sarah McDonald",
                  role: "VP International",
                  image:
                    "https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg",
                },
                {
                  company: "Premium Hospitality Group",
                  sector: "Hotels & Tourism",
                  country: "France",
                  testimonial:
                    "Their hospitality sector knowledge and municipal licensing expertise were invaluable. Excellent service throughout.",
                  author: "Pierre Dubois",
                  role: "Development Director",
                  image:
                    "https://images.pexels.com/photos/14749879/pexels-photo-14749879.jpeg",
                },
                {
                  company: "AgriTech Solutions",
                  sector: "Agriculture Technology",
                  country: "Australia",
                  testimonial:
                    "SafaArban's agricultural sector expertise and government relations made our licensing process efficient and successful.",
                  author: "Michael Thompson",
                  role: "CEO",
                  image:
                    "https://images.pexels.com/photos/3184419/pexels-photo-3184419.jpeg",
                },
              ].map((testimonial, index) => (
                <Card
                  key={index}
                  className="border-gray-200 shadow-sm bg-white"
                >
                  <div className="relative h-32 overflow-hidden rounded-t-lg">
                    <img
                      src={testimonial.image}
                      alt={`${testimonial.company} - ${testimonial.sector}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                      <div className="p-4 text-white">
                        <h4 className="font-bold text-sm">
                          {testimonial.company}
                        </h4>
                        <p className="text-xs opacity-90">
                          {testimonial.sector}
                        </p>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <blockquote className="text-muted italic text-sm mb-3">
                      "{testimonial.testimonial}"
                    </blockquote>
                    <div className="text-xs">
                      <div className="font-semibold text-navy">
                        {testimonial.author}
                      </div>
                      <div className="text-muted">{testimonial.role}</div>
                      <div className="text-coral mt-1">
                        {testimonial.country}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Success Metrics */}
            <div className="mt-16 bg-white rounded-2xl p-8 shadow-sm">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-navy mb-4">
                  Proven Track Record
                </h3>
                <p className="text-muted">
                  Measurable results across diverse industries and business
                  models
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">98%</div>
                  <div className="text-sm text-muted">
                    Approval Success Rate
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">
                    30 days
                  </div>
                  <div className="text-sm text-muted">Average Setup Time</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">
                    5,000+
                  </div>
                  <div className="text-sm text-muted">Jobs Created</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-coral mb-2">95%</div>
                  <div className="text-sm text-muted">Client Satisfaction</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-navy mb-6">
              Ready to Join Our Success Stories?
            </h2>
            <p className="text-lg text-muted mb-8">
              Let's discuss your Saudi business goals and create a tailored
              roadmap for success. Join over 200 international companies who
              chose SafaArban for their market entry.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                asChild
                className="bg-navy text-white hover:bg-navy-600 shadow-lg"
              >
                <Link to="/contact">Schedule Consultation</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
                className="border-gray-300 text-navy hover:bg-gray-50"
              >
                <a
                  href="https://wa.me/966536182180"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Chat on WhatsApp
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
