export type BlogPostCoreMeta = {
  title: string;
  excerpt: string;
  date?: string;
  readTime?: string;
  category?: string;
  image?: string;
};

export type BlogPostMeta = BlogPostCoreMeta & {
  slug: string;
};

const IMAGE_PATTERN = /!\[[^\]]*\]\(([^(\s]+)(?:\s+\"[^\"]*\")?\)/;

function findTitle(lines: string[]): { title: string; index: number } {
  const index = lines.findIndex((line) => line.trim().startsWith("# "));
  if (index === -1) {
    return { title: "Article", index: -1 };
  }
  const title = lines[index].replace(/^#\s+/, "").trim();
  return { title: title || "Article", index };
}

function findMetaLine(lines: string[]): { text: string; index: number } | null {
  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (!trimmed) continue;
    if (/Published:/i.test(trimmed)) {
      return { text: trimmed.replace(/^_+|_+$/g, ""), index: i };
    }
    if (trimmed.startsWith("_") && trimmed.endsWith("_") && trimmed.includes(":")) {
      return { text: trimmed.replace(/^_+|_+$/g, ""), index: i };
    }
  }
  return null;
}

function parseMeta(text?: string) {
  const result: Partial<BlogPostCoreMeta> = {};
  if (!text) return result;
  const segments = text.split("|").map((segment) => segment.trim());
  for (const segment of segments) {
    const [keyRaw, ...rest] = segment.split(":");
    if (!keyRaw || rest.length === 0) continue;
    const key = keyRaw.trim().toLowerCase();
    const value = rest.join(":").trim();
    if (!value) continue;
    if (key.includes("published")) result.date = value;
    else if (key.includes("reading time")) result.readTime = value;
    else if (key.includes("category")) result.category = value;
  }
  return result;
}

function isSkippableParagraph(paragraph: string) {
  return (
    !paragraph ||
    paragraph.startsWith("#") ||
    paragraph.startsWith("![") ||
    paragraph.startsWith("<") ||
    paragraph.startsWith("_") ||
    paragraph.startsWith("(") ||
    /^https?:\/\//i.test(paragraph)
  );
}

function findExcerpt(lines: string[], fromIndex: number): string {
  for (let i = fromIndex + 1; i < lines.length; i++) {
    const paragraph = lines[i].trim();
    if (isSkippableParagraph(paragraph)) continue;
    return paragraph.replace(/^_+|_+$/g, "");
  }
  return "";
}

function findImage(markdown: string): string | undefined {
  const match = IMAGE_PATTERN.exec(markdown);
  return match ? match[1] : undefined;
}

export function extractArticleMeta(markdown: string): BlogPostCoreMeta {
  const lines = markdown.split(/\r?\n/);
  const { title, index: titleIndex } = findTitle(lines);
  const meta = findMetaLine(lines);
  const startIndex = Math.max(titleIndex, meta?.index ?? -1);
  const excerpt = findExcerpt(lines, startIndex);
  const image = findImage(markdown);
  const metaDetails = parseMeta(meta?.text);
  return {
    title,
    excerpt: excerpt || title,
    date: metaDetails.date,
    readTime: metaDetails.readTime,
    category: metaDetails.category,
    image,
  };
}

export function extractPostMeta(slug: string, markdown: string): BlogPostMeta {
  const core = extractArticleMeta(markdown);
  return {
    slug,
    ...core,
  };
}

export function parsePostDate(date?: string): number {
  if (!date) return 0;
  const timestamp = Date.parse(date);
  return Number.isNaN(timestamp) ? 0 : timestamp;
}
