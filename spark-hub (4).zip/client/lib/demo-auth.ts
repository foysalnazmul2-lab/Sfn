export type DemoRole = "customer" | "employee";

export type DemoAccount = {
  email: string;
  passwordHash: string;
  role: DemoRole;
};

const STORAGE_KEY = "demo_accounts";

function loadAccounts(): DemoAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => typeof item?.email === "string" && typeof item?.passwordHash === "string" && (item?.role === "customer" || item?.role === "employee"));
  } catch {
    return [];
  }
}

function saveAccounts(accounts: DemoAccount[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
}

async function hashPassword(password: string): Promise<string> {
  if (window.crypto?.subtle) {
    const enc = new TextEncoder().encode(password);
    const digest = await window.crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
  return btoa(password);
}

export async function createDemoAccount(email: string, password: string, role: DemoRole): Promise<DemoAccount> {
  const normalizedEmail = email.trim().toLowerCase();
  const accounts = loadAccounts();
  if (accounts.some((acct) => acct.email === normalizedEmail)) {
    throw new Error("An account with this email already exists.");
  }
  const passwordHash = await hashPassword(password);
  const account: DemoAccount = { email: normalizedEmail, passwordHash, role };
  saveAccounts([account, ...accounts]);
  return account;
}

export async function authenticateDemoAccount(email: string, password: string): Promise<DemoAccount> {
  const normalizedEmail = email.trim().toLowerCase();
  const accounts = loadAccounts();
  const account = accounts.find((acct) => acct.email === normalizedEmail);
  if (!account) {
    throw new Error("Account not found. Please sign up first.");
  }
  const passwordHash = await hashPassword(password);
  if (passwordHash !== account.passwordHash) {
    throw new Error("Incorrect password.");
  }
  return account;
}

export function seedEmployeeDemoAccount() {
  const accounts = loadAccounts();
  const hasEmployee = accounts.some((acct) => acct.role === "employee");
  if (!hasEmployee) {
    const defaultEmail = "team@safaarban.com";
    const defaultPassword = "safaarban123";
    hashPassword(defaultPassword).then((passwordHash) => {
      const updated = [{ email: defaultEmail, passwordHash, role: "employee" as DemoRole }, ...accounts];
      saveAccounts(updated);
    });
  }
}
