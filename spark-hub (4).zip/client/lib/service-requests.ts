import { getSupabase } from "@/lib/supabase";

export type ServiceRequestStatus = "New" | "In Review" | "In Progress" | "Completed" | "Rejected";

export type ServiceRequest = {
  id: string;
  userId: string;
  email: string;
  service: string;
  description: string;
  status: ServiceRequestStatus;
  createdAt: string;
  updatedAt: string;
};

export type CreateRequestInput = {
  userId: string;
  email: string;
  service: string;
  description: string;
};

const TABLE = "service_requests";
const STORAGE_PREFIX = "demo_requests_";

const toRequest = (row: any): ServiceRequest => ({
  id: row.id,
  userId: row.user_id ?? row.userId ?? "demo",
  email: row.email ?? "",
  service: row.service,
  description: row.description,
  status: (row.status as ServiceRequestStatus) ?? "New",
  createdAt: row.created_at ?? row.createdAt ?? new Date().toISOString(),
  updatedAt: row.updated_at ?? row.updatedAt ?? row.created_at ?? row.createdAt ?? new Date().toISOString(),
});

async function fetchDemoRequests(email: string) {
  const raw = localStorage.getItem(`${STORAGE_PREFIX}${email}`);
  if (!raw) return [] as ServiceRequest[];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [] as ServiceRequest[];
    return parsed.map(toRequest);
  } catch {
    return [] as ServiceRequest[];
  }
}

function storeDemoRequests(email: string, requests: ServiceRequest[]) {
  localStorage.setItem(`${STORAGE_PREFIX}${email}`, JSON.stringify(requests));
}

export async function listCustomerRequests({ userId, email }: { userId: string; email: string }): Promise<ServiceRequest[]> {
  const supabase = getSupabase();
  if (!supabase) {
    const data = await fetchDemoRequests(email);
    return data.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  const { data, error } = await supabase
    .from(TABLE)
    .select("id,user_id,email,service,description,status,created_at,updated_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []).map(toRequest);
}

export async function listAllRequests(): Promise<ServiceRequest[]> {
  const supabase = getSupabase();
  if (!supabase) {
    const results: ServiceRequest[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith(STORAGE_PREFIX)) continue;
      const email = key.replace(STORAGE_PREFIX, "");
      const entries = await fetchDemoRequests(email);
      results.push(...entries);
    }
    return results.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  const { data, error } = await supabase
    .from(TABLE)
    .select("id,user_id,email,service,description,status,created_at,updated_at")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []).map(toRequest);
}

export async function createServiceRequest(input: CreateRequestInput): Promise<ServiceRequest> {
  const supabase = getSupabase();
  if (!supabase) {
    const now = new Date().toISOString();
    const request: ServiceRequest = {
      id: crypto.randomUUID(),
      userId: input.userId,
      email: input.email,
      service: input.service,
      description: input.description,
      status: "New",
      createdAt: now,
      updatedAt: now,
    };
    const existing = await fetchDemoRequests(input.email);
    const next = [request, ...existing];
    storeDemoRequests(input.email, next);
    return request;
  }
  const payload = {
    user_id: input.userId,
    email: input.email,
    service: input.service,
    description: input.description,
    status: "New" satisfies ServiceRequestStatus,
  };
  const { data, error } = await supabase.from(TABLE).insert(payload).select("id,user_id,email,service,description,status,created_at,updated_at").single();
  if (error) throw new Error(error.message);
  return toRequest(data);
}

export async function updateServiceRequestStatus({ id, status, email }: { id: string; status: ServiceRequestStatus; email?: string }): Promise<ServiceRequest> {
  const supabase = getSupabase();
  if (!supabase) {
    if (!email) throw new Error("Email required for demo data updates");
    const requests = await fetchDemoRequests(email);
    const idx = requests.findIndex((item) => item.id === id);
    if (idx === -1) throw new Error("Request not found");
    const next = [...requests];
    next[idx] = { ...next[idx], status, updatedAt: new Date().toISOString() };
    storeDemoRequests(email, next);
    return next[idx];
  }
  const { data, error } = await supabase
    .from(TABLE)
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select("id,user_id,email,service,description,status,created_at,updated_at")
    .single();
  if (error) throw new Error(error.message);
  return toRequest(data);
}
