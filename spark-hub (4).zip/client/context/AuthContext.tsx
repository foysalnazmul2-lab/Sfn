import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { getSupabase } from "@/lib/supabase";

export type AuthState = {
  user: { id: string; email?: string | null } | null;
  role: "customer" | "employee" | null;
  loading: boolean;
};

const Ctx = createContext<AuthState>({ user: null, role: null, loading: true });

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({ user: null, role: null, loading: true });

  useEffect(() => {
    const supabase = getSupabase();
    if (!supabase) {
      // Demo auth fallback
      const loadDemo = () => {
        try {
          const raw = localStorage.getItem("demo_user");
          if (raw) {
            const demo = JSON.parse(raw);
            const role = (demo.role as AuthState["role"]) || (String(demo.email || "").endsWith("@safaarban.com") ? "employee" : "customer");
            setState({ user: { id: "demo", email: demo.email }, role, loading: false });
          } else {
            setState({ user: null, role: null, loading: false });
          }
        } catch {
          setState({ user: null, role: null, loading: false });
        }
      };
      loadDemo();
      const handler = () => loadDemo();
      window.addEventListener("demo-auth-changed", handler as EventListener);
      return () => window.removeEventListener("demo-auth-changed", handler as EventListener);
    }
    const computeRole = (email?: string | null) => {
      return email?.endsWith("@safaarban.com") ? "employee" : "customer";
    };
    supabase.auth.getSession().then(({ data }) => {
      const u = data.session?.user ?? null;
      const role = (u?.user_metadata as any)?.role || computeRole(u?.email);
      setState({ user: u, role, loading: false });
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ?? null;
      const role = (u?.user_metadata as any)?.role || computeRole(u?.email);
      setState({ user: u, role, loading: false });
    });
    return () => {
      sub.subscription.unsubscribe();
    };
  }, []);

  const value = useMemo(() => state, [state]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}
