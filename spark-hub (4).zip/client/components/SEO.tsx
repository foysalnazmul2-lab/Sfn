import { useEffect } from "react";

export type SEOProps = {
  title: string;
  description: string;
  canonical?: string;
  keywords?: string[];
  ogImage?: string;
  type?: "website" | "article" | "product" | "blog";
  jsonLd?: Record<string, any>[];
};

function setMeta(name: string, content: string) {
  let el = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute("name", name);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setMetaProperty(property: string, content: string) {
  let el = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute("property", property);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

export default function SEO({ title, description, canonical, keywords, ogImage, type = "website", jsonLd }: SEOProps) {
  useEffect(() => {
    if (typeof document === "undefined") return;

    document.title = title;

    setMeta("description", description);
    if (keywords && keywords.length) setMeta("keywords", keywords.join(", "));

    const url = canonical || (typeof window !== "undefined" ? window.location.href : "");
    if (url) setLink("canonical", url);

    // OpenGraph
    setMetaProperty("og:title", title);
    setMetaProperty("og:description", description);
    if (url) setMetaProperty("og:url", url);
    setMetaProperty("og:type", type === "article" || type === "blog" ? "article" : "website");
    setMetaProperty("og:site_name", "SafaArban");
    if (ogImage) setMetaProperty("og:image", ogImage);

    // Twitter
    setMeta("twitter:card", ogImage ? "summary_large_image" : "summary");
    setMeta("twitter:title", title);
    setMeta("twitter:description", description);
    if (ogImage) setMeta("twitter:image", ogImage);

    // JSON-LD structured data
    if (jsonLd && jsonLd.length) {
      // Remove previous injected scripts from this component
      const prev = document.querySelectorAll('script[data-seo-jsonld="true"]');
      prev.forEach((n) => n.parentElement?.removeChild(n));
      jsonLd.forEach((obj) => {
        const script = document.createElement("script");
        script.type = "application/ld+json";
        script.setAttribute("data-seo-jsonld", "true");
        script.text = JSON.stringify(obj);
        document.head.appendChild(script);
      });
    }
  }, [title, description, canonical, JSON.stringify(keywords), ogImage, type, JSON.stringify(jsonLd)]);

  return null;
}
