import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

export default function ProtectedRoute({ children, allowedRoles }: { children: JSX.Element; allowedRoles?: ("customer" | "employee")[] }) {
  const { user, role, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="p-8 text-center">Loading…</div>;
  if (!user) return <Navigate to={allowedRoles?.includes("employee") ? "/admin-auth" : "/auth"} state={{ from: location }} replace />;
  if (allowedRoles && !allowedRoles.includes(role || "customer")) return <Navigate to="/" replace />;
  return children;
}
