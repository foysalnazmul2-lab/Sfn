import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function ContactWidget() {
  const [open, setOpen] = useState(false);
  return (
    <div className="fixed bottom-6 right-6 z-50">
      {open && (
        <div className="mb-3 w-64 rounded-xl border border-gray-200 bg-white shadow-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100">
            <div className="font-semibold text-navy text-sm">Need help?</div>
            <div className="text-xs text-gray-500">Contact us instantly</div>
          </div>
          <div className="p-3 space-y-2">
            <Button asChild className="w-full bg-[#25D366] hover:bg-[#1fb457] text-white">
              <a href="https://wa.me/966536182180" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">
                WhatsApp Chat
              </a>
            </Button>
            <Button asChild variant="outline" className="w-full border-gray-300 text-navy hover:bg-gray-50">
              <a href="tel:+966536182180" aria-label="Call us now">Call Now</a>
            </Button>
            <Button asChild variant="outline" className="w-full border-gray-300 text-navy hover:bg-gray-50">
              <Link to="/contact" aria-label="Open contact form">Contact Form</Link>
            </Button>
          </div>
        </div>
      )}
      <Button
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label="Quick contact menu"
        className="rounded-full shadow-lg bg-navy text-white hover:bg-navy-600 h-12 w-12 p-0"
        title="Contact"
      >
        {open ? (
          <span className="text-xl leading-none">×</span>
        ) : (
          <span className="text-lg leading-none">✉️</span>
        )}
      </Button>
    </div>
  );
}
