import { Link } from "react-router-dom";
import { ArrowRight, CalendarDays, Clock3 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BlogPostMeta } from "@/lib/blog";
import { cn } from "@/lib/utils";

const FALLBACK_GRADIENTS = [
  "from-navy to-navy-600",
  "from-coral-500 to-amber-400",
  "from-sky-500 to-indigo-600",
  "from-emerald-500 to-teal-600",
];

function getFallbackClasses(slug: string) {
  const index = Math.abs(slug.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0)) % FALLBACK_GRADIENTS.length;
  return FALLBACK_GRADIENTS[index];
}

export function PostCard({ post }: { post: BlogPostMeta }) {
  const fallback = getFallbackClasses(post.slug);

  return (
    <Card className="group flex h-full flex-col overflow-hidden border-gray-200 shadow-sm transition-shadow hover:shadow-lg">
      <div className="relative h-48 w-full overflow-hidden">
        {post.image ? (
          <img
            src={post.image}
            alt={post.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className={cn("flex h-full w-full items-center justify-center bg-gradient-to-br text-white", fallback)}>
            <span className="text-3xl font-semibold uppercase tracking-[0.4em]">{post.title.slice(0, 1)}</span>
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/50 to-transparent" />
        {post.category && (
          <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-navy shadow-sm">
            {post.category}
          </span>
        )}
      </div>
      <CardContent className="flex flex-1 flex-col p-6">
        <h3 className="text-xl font-semibold text-navy transition-colors group-hover:text-coral">
          <Link to={`/blog/${post.slug}`}>{post.title}</Link>
        </h3>
        <p className="mt-3 line-clamp-3 text-sm text-muted">{post.excerpt}</p>
        <div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-muted">
          {post.date && (
            <span className="inline-flex items-center gap-1">
              <CalendarDays className="h-4 w-4" />
              {post.date}
            </span>
          )}
          {post.readTime && (
            <span className="inline-flex items-center gap-1">
              <Clock3 className="h-4 w-4" />
              {post.readTime}
            </span>
          )}
        </div>
        <div className="mt-6 flex items-center justify-between">
          <Button asChild variant="ghost" className="px-0 text-sm font-semibold text-coral hover:text-coral">
            <Link to={`/blog/${post.slug}`}>
              Continue Reading
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          {post.category ? (
            <Badge variant="outline" className="border-coral/30 bg-coral/10 text-coral">
              {post.category}
            </Badge>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
