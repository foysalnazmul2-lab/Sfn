import { Link } from "react-router-dom";
import { ArrowRight, CalendarDays, Clock3, Share2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BlogPostMeta } from "@/lib/blog";
import { cn } from "@/lib/utils";

const FALLBACK_GRADIENTS = [
  "from-navy via-navy-600 to-navy-800",
  "from-coral-500 via-rose-500 to-amber-400",
  "from-indigo-500 via-sky-500 to-cyan-400",
];

function getFallbackClasses(slug: string) {
  const hash = slug.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return FALLBACK_GRADIENTS[Math.abs(hash) % FALLBACK_GRADIENTS.length];
}

export function FeaturedPostCard({ post }: { post: BlogPostMeta }) {
  const fallback = getFallbackClasses(post.slug);

  return (
    <Card className="overflow-hidden border-none shadow-xl">
      <div className="grid gap-0 lg:grid-cols-[1.4fr_1fr]">
        <div className="relative min-h-[320px]">
          {post.image ? (
            <img
              src={post.image}
              alt={post.title}
              className="absolute inset-0 h-full w-full object-cover"
            />
          ) : (
            <div className={cn("absolute inset-0 bg-gradient-to-br", fallback)} />
          )}
          <div className="absolute inset-0 bg-gradient-to-tr from-black/70 via-black/20 to-transparent" />
          <div className="relative flex h-full flex-col justify-end gap-4 p-8 text-white lg:p-12">
            {post.category && (
              <Badge variant="outline" className="w-fit border-white/40 bg-white/10 text-white">
                {post.category}
              </Badge>
            )}
            <h2 className="text-3xl font-semibold leading-tight lg:text-4xl">{post.title}</h2>
            <p className="max-w-2xl text-base text-white/80">{post.excerpt}</p>
            <div className="flex flex-wrap items-center gap-4 text-sm text-white/80">
              {post.date && (
                <span className="inline-flex items-center gap-2">
                  <CalendarDays className="h-4 w-4" />
                  {post.date}
                </span>
              )}
              {post.readTime && (
                <span className="inline-flex items-center gap-2">
                  <Clock3 className="h-4 w-4" />
                  {post.readTime}
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Button asChild className="bg-white text-navy hover:bg-white/90">
                <Link to={`/blog/${post.slug}`}>
                  Read the Full Insight
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                variant="outline"
                className="border-white/60 bg-transparent text-white hover:bg-white/10"
                onClick={() => {
                  if (typeof navigator !== "undefined" && navigator.share) {
                    navigator.share({ title: post.title, url: `${window.location.origin}/blog/${post.slug}` }).catch(() => undefined);
                  } else if (typeof window !== "undefined") {
                    window.open(`${window.location.origin}/blog/${post.slug}`, "_blank", "noopener,noreferrer");
                  }
                }}
              >
                <Share2 className="h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
        </div>
        <CardContent className="flex flex-col justify-between gap-8 bg-white/60 p-8 backdrop-blur lg:p-12">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-navy">Why this matters</h3>
            <p className="text-sm text-muted">
              Stay ahead of regulatory shifts impacting foreign investment in Saudi Arabia. We unpack timelines, fees,
              and strategic moves so your team can execute with confidence.
            </p>
          </div>
          <div className="grid gap-4 text-sm text-muted">
            <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
              <p className="font-semibold text-navy">Strategic guidance</p>
              <p className="mt-1 text-xs text-muted">Leverage detailed walkthroughs to prepare investor documentation and avoid rework.</p>
            </div>
            <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
              <p className="font-semibold text-navy">SafaArban advantage</p>
              <p className="mt-1 text-xs text-muted">Practical tips from engagements with multinational and regional investors.</p>
            </div>
          </div>
        </CardContent>
      </div>
    </Card>
  );
}
