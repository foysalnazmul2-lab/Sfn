import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Header() {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-white/75 border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <nav className="flex items-center justify-between py-4">
          {/* Brand */}
          <Link to="/" className="flex items-center">
            <svg
              width="160"
              height="36"
              viewBox="0 0 160 36"
              xmlns="http://www.w3.org/2000/svg"
            >
              <text
                x="0"
                y="28"
                fontFamily="Inter, sans-serif"
                fontSize="28"
                fontWeight="800"
                fill="#0F2847"
              >
                Safa<tspan fill="#E9443E">Arban</tspan>
              </text>
            </svg>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <Link
              to="/services"
              className={`font-semibold transition-colors ${
                isActive("/services")
                  ? "text-coral"
                  : "text-navy hover:text-coral"
              }`}
            >
              Services
            </Link>
            <Link
              to="/about"
              className={`font-semibold transition-colors ${
                isActive("/about") ? "text-coral" : "text-navy hover:text-coral"
              }`}
            >
              About
            </Link>
            <Link
              to="/blog"
              className={`font-semibold transition-colors ${
                isActive("/blog") ? "text-coral" : "text-navy hover:text-coral"
              }`}
            >
              Blog
            </Link>
            <Link
              to="/contact"
              className={`font-semibold transition-colors ${
                isActive("/contact")
                  ? "text-coral"
                  : "text-navy hover:text-coral"
              }`}
            >
              Contact
            </Link>
          </div>

          {/* CTA Buttons */}
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              asChild
              className="hidden sm:inline-flex border-gray-300 text-navy hover:bg-gray-50"
            >
              <a
                href="https://wa.me/966536182180"
                target="_blank"
                rel="noopener noreferrer"
              >
                WhatsApp
              </a>
            </Button>
            <Button
              variant="outline"
              size="sm"
              asChild
              className="border-gray-300 text-navy hover:bg-gray-50"
            >
              <Link to="/auth">Login</Link>
            </Button>
            <Button
              variant="outline"
              size="sm"
              asChild
              className="hidden md:inline-flex border-gray-300 text-navy hover:bg-gray-50"
            >
              <Link to="/admin-auth">Employee</Link>
            </Button>
            <Button
              size="sm"
              asChild
              className="bg-navy text-white hover:bg-navy-600 shadow-lg"
            >
              <Link to="/contact">Request Quote</Link>
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
