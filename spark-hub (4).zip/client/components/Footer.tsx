import { Link } from "react-router-dom";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy text-gray-100 py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <svg
                width="160"
                height="36"
                viewBox="0 0 160 36"
                xmlns="http://www.w3.org/2000/svg"
              >
                <text
                  x="0"
                  y="28"
                  fontFamily="Inter, sans-serif"
                  fontSize="28"
                  fontWeight="800"
                  fill="#ffffff"
                >
                  Safa<tspan fill="#E9443E">Arban</tspan>
                </text>
              </svg>
            </div>
            <p className="text-sm text-gray-300 mb-4 max-w-md">
              Consulting partner for foreign investors in Saudi Arabia — company
              setup, licensing, and compliance. No prices displayed; request a
              proposal tailored to your needs.
            </p>
          </div>

          {/* Services */}
          <div>
            <h5 className="font-semibold text-white mb-3">Services</h5>
            <ul className="space-y-2 text-sm">
              <li>
                <Link
                  to="/services/misa-licensing"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  MISA Investment License
                </Link>
              </li>
              <li>
                <Link
                  to="/blog/commercial-registration-cr-process-saudi-arabia"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Company Formation (CR)
                </Link>
              </li>
              <li>
                <Link
                  to="/blog/zatca-e-invoicing-compliance-guide"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  ZATCA E-Invoicing Compliance
                </Link>
              </li>
              <li>
                <Link
                  to="/blog/gosi-qiwa-registration-foreign-companies"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  GOSI & Qiwa Registration
                </Link>
              </li>
              <li>
                <Link
                  to="/blog/municipality-license-requirements-by-city"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Municipality License
                </Link>
              </li>
              <li>
                <Link
                  to="/blog/manufacturing-license-requirements"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Industrial/Sector Licenses
                </Link>
              </li>
              <li>
                <Link
                  to="/blog/saudi-premium-residency-program-sp1-guide"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Premium Residency
                </Link>
              </li>
            </ul>
            <div className="mt-4">
              <label htmlFor="service-select" className="sr-only">
                Quick service chooser
              </label>
              <select
                id="service-select"
                className="w-full bg-navy-600/40 border border-navy-500 text-gray-100 text-sm rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-coral"
                onChange={(e) => {
                  const v = e.target.value;
                  if (v) window.location.href = v;
                }}
                defaultValue=""
              >
                <option value="" disabled>
                  Choose a service…
                </option>
                <option value="/services/misa-licensing">
                  MISA Investment License
                </option>
                <option value="/blog/commercial-registration-cr-process-saudi-arabia">
                  Company Formation (CR)
                </option>
                <option value="/blog/zatca-e-invoicing-compliance-guide">
                  ZATCA E-Invoicing
                </option>
                <option value="/blog/gosi-qiwa-registration-foreign-companies">
                  GOSI & Qiwa
                </option>
                <option value="/blog/municipality-license-requirements-by-city">
                  Municipality License
                </option>
                <option value="/blog/manufacturing-license-requirements">
                  Industrial/Sector Licenses
                </option>
                <option value="/blog/saudi-premium-residency-program-sp1-guide">
                  Premium Residency
                </option>
              </select>
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h5 className="font-semibold text-white mb-3">Company</h5>
            <ul className="space-y-2 text-sm">
              <li>
                <Link
                  to="/about"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  to="/services"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Services
                </Link>
              </li>
              <li>
                <Link
                  to="/blog"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Contact
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Contact Info */}
        <div className="mt-8 pt-8 border-t border-navy-600">
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-1 text-gray-300">
              <p>
                Phone/WhatsApp:{" "}
                <a
                  href="https://wa.me/966536182180"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-coral hover:underline"
                >
                  +966 536 182 180
                </a>
              </p>
              <p>
                Email:{" "}
                <a
                  href="mailto:hello@safaarban.com"
                  className="text-coral hover:underline"
                >
                  hello@safaarban.com
                </a>
              </p>
              <p>Riyadh, Kingdom of Saudi Arabia</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-6 border-t border-navy-600/50 flex flex-col sm:flex-row justify-between items-center text-sm text-gray-400">
          <div>© {currentYear} SafaArban. All rights reserved.</div>
          <div className="mt-2 sm:mt-0 opacity-85">
            Made with ♥ in Saudi Arabia
          </div>
        </div>
      </div>
    </footer>
  );
}
