# Commercial Registration (CR) Process in Saudi Arabia: Complete Guide 2024

_Published: January 11, 2024 | Reading Time: 12 minutes | Category: Company Formation_

![Commercial Registration at Ministry Office](https://images.pexels.com/photos/5668511/pexels-photo-5668511.jpeg)
_Official Ministry of Commerce counter supporting CR issuance and verification_

Commercial Registration (CR) is the cornerstone of business operations in Saudi Arabia. Every company, regardless of size or sector, must obtain a valid CR from the Ministry of Commerce to operate legally in the Kingdom. This comprehensive guide walks you through the entire CR process for foreign companies in 2024.

## What is Commercial Registration (CR)?

Commercial Registration is an official government document that:

- **Legally establishes** your business entity in Saudi Arabia
- **Authorizes commercial activities** within specified business scope
- **Provides legal identity** for contracts, banking, and transactions
- **Enables tax registration** with ZATCA and other authorities
- **Facilitates business licensing** from various government bodies

## Types of Commercial Registration

### Limited Liability Company (LLC)

- **Ownership**: 100% foreign ownership allowed
- **Minimum Capital**: SAR 500,000
- **Shareholders**: 1-50 shareholders
- **Liability**: Limited to capital contribution
- **Management**: Board of directors or managers

### Branch of Foreign Company

- **Ownership**: Extension of parent company
- **Minimum Capital**: SAR 500,000 allocated capital
- **Operations**: Specific activities only
- **Liability**: Parent company liable
- **Management**: Appointed branch manager

### Joint Stock Company (JSC)

- **Ownership**: Public or closed joint stock
- **Minimum Capital**: SAR 2 million (closed) / SAR 10 million (public)
- **Shareholders**: Minimum 2 (closed) / 5 (public)
- **Liability**: Limited to share value
- **Management**: Board of directors

## Pre-Registration Requirements

### MISA Investment License

Before applying for CR, foreign companies must obtain:

- Valid MISA investment license
- Approved business activities
- Confirmed investment amount
- Sector-specific permits (if required)

### Name Reservation

- Check name availability on MoC portal
- Reserve chosen company name
- Ensure compliance with naming rules
- Avoid prohibited words or concepts

![CR Documentation and Legalization](https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg)
_Professional document preparation, translation, and attestation for CR_

## Required Documents for CR Application

### Core Corporate Documents

1. **MISA Investment License**
   - Original license
   - Investment certificate
   - Business activities approval
   - Sector permits (if applicable)

2. **Articles of Association**
   - Memorandum of association
   - Company bylaws
   - Shareholding structure
   - Management provisions

3. **Shareholder Documentation**
   - Passport copies (notarized)
   - Criminal background checks
   - Financial capability certificates
   - Professional qualifications

### Legal Documentation

1. **Powers of Attorney**
   - Board resolutions
   - Management appointments
   - Authorized signatories
   - Legal representatives

2. **Certified Translations**
   - All foreign documents in Arabic
   - Certified by approved translators
   - Attested by relevant authorities
   - Properly notarized

### Financial Documents

1. **Capital Evidence**
   - Bank deposit certificates
   - Fund transfer documents
   - Capital contribution proof
   - Financial guarantees

2. **Corporate Financials**
   - Parent company statements
   - Credit rating certificates
   - Banking relationships
   - Investment capacity proof

![MoC Online Portal Filing](https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg)
_Submitting CR applications and fee payments through the MoC digital portal_

## Step-by-Step CR Application Process

### Phase 1: Preparation (1-2 weeks)

#### Document Assembly

1. **Collect all required documents**
2. **Translate foreign documents to Arabic**
3. **Notarize and attest all papers**
4. **Organize digital copies**

#### Legal Structure Setup

1. **Draft Articles of Association**
2. **Define business activities**
3. **Establish shareholding structure**
4. **Appoint management team**

### Phase 2: Name Reservation (3-5 days)

#### Name Selection Process

1. **Check name availability online**
2. **Submit name reservation request**
3. **Pay reservation fees**
4. **Receive name approval certificate**

#### Name Requirements

- Must be in Arabic and English
- Cannot conflict with existing names
- Must reflect business activities
- Should comply with Islamic principles

### Phase 3: Application Submission (1 week)

#### Online Portal Filing

1. **Create MoC account**
2. **Complete application forms**
3. **Upload all documents**
4. **Pay processing fees**
5. **Submit application**

#### Application Review

1. **Initial document check**
2. **Completeness verification**
3. **Legal compliance review**
4. **Query resolution**

### Phase 4: Processing and Approval (2-3 weeks)

#### Technical Review

1. **Business activities assessment**
2. **Capital adequacy check**
3. **Legal structure validation**
4. **Compliance verification**

#### Government Approvals

1. **Ministry of Commerce review**
2. **Inter-ministry coordination**
3. **Sector-specific clearances**
4. **Final authorization**

### Phase 5: CR Issuance (3-5 days)

#### Certificate Generation

1. **Digital CR creation**
2. **Physical certificate printing**
3. **Official stamping and sealing**
4. **Delivery arrangement**

## Business Activities Classification

### Primary Activities

- Main business operations
- Core revenue sources
- Primary market focus
- Key service offerings

### Secondary Activities

- Supporting operations
- Additional revenue streams
- Ancillary services
- Future expansion plans

### Activity Codes (ISIC)

Saudi Arabia uses International Standard Industrial Classification (ISIC) codes:

- **Manufacturing**: Codes 10-33
- **Construction**: Codes 41-43
- **Trade**: Codes 45-47
- **Services**: Codes 49-99

## Capital Requirements by Entity Type

### LLC Capital Structure

- **Minimum**: SAR 500,000
- **Payment**: 25% minimum at incorporation
- **Currency**: Saudi Riyals
- **Evidence**: Bank deposit certificate

### Branch Capital Allocation

- **Minimum**: SAR 500,000
- **Type**: Allocated capital from parent
- **Purpose**: Local operations only
- **Transfer**: From parent company account

### JSC Capital Requirements

- **Closed JSC**: SAR 2 million minimum
- **Public JSC**: SAR 10 million minimum
- **Subscription**: Fully subscribed at incorporation
- **Payment**: 25% minimum paid-up

## Timeline and Fees

### Standard Processing Timeline

- **Name reservation**: 3-5 days
- **Document preparation**: 1-2 weeks
- **Application processing**: 2-3 weeks
- **CR issuance**: 3-5 days
- **Total duration**: 4-6 weeks

### Government Fees Structure

1. **Name reservation**: SAR 500
2. **CR application**: SAR 1,000
3. **CR certificate**: SAR 1,000
4. **Annual renewal**: SAR 1,000

### Professional Service Costs

- **Legal drafting**: SAR 15,000-25,000
- **Translation services**: SAR 5,000-8,000
- **Attestation costs**: SAR 3,000-5,000
- **Consulting fees**: SAR 10,000-20,000

![Chamber of Commerce Membership](https://images.pexels.com/photos/3184632/pexels-photo-3184632.jpeg)
_Chamber of Commerce registration and municipal coordination after CR_

## Post-CR Registration Requirements

### Immediate Next Steps (Within 30 days)

1. **Chamber of Commerce Registration**
   - Local chamber membership
   - Business classification
   - Membership fees payment
   - Certificate issuance

2. **Municipality License**
   - Location-specific permits
   - Activity approvals
   - Safety clearances
   - Signage permissions

3. **ZATCA Tax Registration**
   - Tax identification number
   - VAT registration (if applicable)
   - E-invoicing setup
   - Compliance requirements

4. **GOSI Social Insurance**
   - Employer registration
   - Social insurance setup
   - Employee coverage
   - Contribution calculations

### Banking and Financial Setup

1. **Corporate Bank Account**
   - CR certificate required
   - Capital deposit verification
   - Authorized signatory setup
   - Banking relationship establishment

2. **Financial Compliance**
   - Accounting system setup
   - Auditor appointment
   - Financial reporting preparation
   - Regulatory compliance

## Common Challenges and Solutions

### Documentation Issues

**Challenge**: Incomplete or incorrect documentation
**Solution**: Professional document review and preparation services

**Challenge**: Translation and attestation delays
**Solution**: Early engagement with certified service providers

### Approval Delays

**Challenge**: Extended processing times
**Solution**: Complete application submission and professional follow-up

**Challenge**: Government query responses
**Solution**: Expert consultation and prompt response management

### Capital Requirements

**Challenge**: Capital transfer complications
**Solution**: Banking relationship establishment and expert guidance

**Challenge**: Currency conversion issues
**Solution**: Professional foreign exchange management

## Sector-Specific Considerations

### Manufacturing Companies

- Industrial license requirements
- Environmental impact assessments
- Safety and health permits
- Location-specific approvals

### Technology Companies

- Software licensing
- Data protection compliance
- Intellectual property registration
- Cybersecurity requirements

### Trading Companies

- Import/export licenses
- Customs registration
- Product-specific permits
- Distribution agreements

### Service Companies

- Professional licensing
- Service quality standards
- Customer protection compliance
- Industry-specific regulations

## CR Renewal and Modifications

### Annual Renewal Process

- **Deadline**: Before expiration date
- **Requirements**: Updated documents
- **Fees**: SAR 1,000 annually
- **Processing**: 3-5 business days

### Modification Procedures

1. **Activity Changes**
   - Business scope expansion
   - New activity additions
   - Activity modifications
   - Regulatory approvals

2. **Capital Changes**
   - Capital increase procedures
   - Shareholder approvals
   - Legal documentation
   - Government notifications

3. **Management Changes**
   - Director appointments
   - Signatory updates
   - Power of attorney changes
   - Legal representative modifications

## Compliance and Ongoing Requirements

### Annual Obligations

- CR renewal before expiration
- Financial statements filing
- Tax return submissions
- Regulatory compliance reports

### Record Keeping Requirements

- Corporate resolutions
- Financial records
- Legal correspondence
- Compliance documentation

### Regulatory Monitoring

- Law and regulation updates
- Industry-specific changes
- Compliance requirement modifications
- Penalty avoidance strategies

## Expert Tips for Success

### Preparation Best Practices

1. **Start early**: Begin preparation 2-3 months in advance
2. **Professional guidance**: Engage experienced legal counsel
3. **Complete documentation**: Ensure all documents are current and complete
4. **Quality translations**: Use certified translation services

### Application Strategy

1. **Clear activity definition**: Be specific about business activities
2. **Adequate capitalization**: Ensure sufficient capital for operations
3. **Professional presentation**: Organize documents professionally
4. **Timely responses**: Respond quickly to government queries

### Post-Registration Success

1. **Immediate compliance**: Complete all post-CR requirements promptly
2. **Professional relationships**: Build relationships with government officials
3. **Ongoing monitoring**: Stay updated on regulatory changes
4. **Expert support**: Maintain professional service relationships

## Conclusion

Commercial Registration is the foundation of business operations in Saudi Arabia. While the process has been streamlined through digital platforms, success still requires careful preparation, complete documentation, and professional guidance.

The Saudi government's commitment to business facilitation, combined with Vision 2030 objectives, has made CR registration more efficient than ever. With proper planning and expert support, foreign companies can successfully establish their legal presence in the Kingdom and begin operations quickly.

For comprehensive support with your Commercial Registration process, contact SafaArban's expert team. We provide end-to-end services from document preparation to final CR issuance, ensuring smooth and efficient processing.

---

_This article is for informational purposes only and does not constitute legal advice. Regulations may change, and specific circumstances may require different approaches. Always consult with qualified professionals for your specific situation._
